/**
 * @(#)CustomGetPackages.java
 * 
 */
package calypsox.tk.util;


import java.util.Vector;
import com.calypso.tk.util.GetPackages;

/**
 * CustomGetPackages class extends calypso 
 * com.calypso.tk.util.GetPackages class .
 * 
 * This class helps to add  new package.
 * 
 * @author Siva Sankara Reddy Anyam
 * @version 1.0
 */
public class CustomGetPackages implements GetPackages  {
	
	/**
	 * This method returns a Vector containing the names 
	 * of the custom packages.
	 * 
	 *  @return Vector
	 */
    public Vector getPackages() {
        Vector<String> v = new Vector<String>();
        v.addElement("com.banif");
        return v;
    }
}
