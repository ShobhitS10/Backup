package com.banif.tk.bo.sql;

/* Java imports. */
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.Statement;

/* Calypso imports. */
import com.banif.tk.bo.FXSpotPosition;
import com.banif.tk.util.FXSpotPositionArray;
import com.calypso.tk.core.JDate;
import com.calypso.tk.core.Log;
import com.calypso.tk.core.PersistenceException;
import com.calypso.tk.core.Util;
import com.calypso.tk.core.sql.DeadLockException;
import com.calypso.tk.core.sql.JResultSet;
import com.calypso.tk.core.sql.ioSQL;
import com.calypso.tk.core.sql.ioSQLBase;
/* End imports. */

/**
 * This class is connect with fx_spot_position table and retrieve the
 * values for the data given in report. Startdate, Enddate, Currency values are
 * used to form query.
 * Using this to retrieve or save data from table fx_spot_position.
 *
 * @author momohame
 * @date 12/20/2009
 * @version 1.0
 *
 */
public class FXSpotPositionSQL extends ioSQL {
   /* Constants. */
    protected String insert_fx_spot_pos = "INSERT INTO fx_spot_position(position_date,currency_code,cumulative_amount,simulation_amount,dual_ccy_amount,fips_brl_amount) VALUES(?,?,?,?,?,?)";
    protected String select_fx_spot_pos = "SELECT position_date, currency_code, cumulative_amount, simulation_amount , dual_ccy_amount, fips_brl_amount FROM fx_spot_position WHERE";
    static FXSpotPositionSQL _patch = null;

    /**
     * Default Constructor.
     */
    public FXSpotPositionSQL() {
    }

    /**
     * getSaver().
     * @return FXSpotPositionSQL - patch
     */
    protected static FXSpotPositionSQL getSaver() {
        if (_patch != null) {
            return _patch;
            } else {
            _patch = new FXSpotPositionSQL();
        }

        return _patch;
    }

    /**
     * Method to save fx spoition .
     * @param fXSpotPosition - fx sposition
     * @return boolean - result
     * @throws PersistenceException - exception
     */
    /**
     * @author          : Shobhit Sachdeva
     * @Date(DD/MM/YYYY): 10/11/2014 - updated
     * @Description     : Updated deprecated method ioSQL.newConnection() with ioSQLBase.getConnection().
     */
    public boolean save(FXSpotPosition fXSpotPosition)
        throws PersistenceException {
        Connection connection = null;

        try {
            int i = 0;

            connection = ioSQLBase.getConnection();

            do {
                if (fXSpotPosition == null) {
                    break;
                }

                try {
                    save(fXSpotPosition, connection);

                    break;
                } catch (DeadLockException deadlockexception) {
                          ioSQL.rollback(connection);
                          Log.error(Log.SQL, deadlockexception);
                    if (++i >= 10) {
                        throw deadlockexception;
                    }
                }
            } while (true);

            ioSQL.commit(connection);
        } catch (Throwable throwable) {
            Log.error(Log.SQL, throwable);
            ioSQL.rollback(connection);
            throw new PersistenceException(throwable);
        } finally {
            ioSQL.releaseConnection(connection);
        }
        return true;
    }

    /**
     * method to save FX spot position.
     * @param fXSpotPosition - fx spot position
     * @param connection - connection object
     * @return boolean - result
     * @throws PersistenceException - exception
     * @throws SQLException - sql exception
     */
    public boolean save(FXSpotPosition fXSpotPosition, Connection connection)
        throws PersistenceException, SQLException {
        boolean saveStatus = false;
        PreparedStatement preparedstatement;
        preparedstatement = null;

        try {

            preparedstatement = ioSQL.newPreparedStatement(
                    connection, insert_fx_spot_pos);

            int k = 1;

            if (fXSpotPosition != null) {
                   preparedstatement.setDate(
                    k++, ioSQL.toSQLDate(fXSpotPosition.getDate()));
                preparedstatement.setString(k++, fXSpotPosition.getCurrency());
                preparedstatement.setDouble(
                    k++, fXSpotPosition.getFXCumulate());
                preparedstatement.setDouble(
                    k++, fXSpotPosition.getSimulation());
                preparedstatement.setDouble(
                    k++, fXSpotPosition.getDualCurrency());
                preparedstatement.setDouble(k++, fXSpotPosition.getFipsBlr());

                preparedstatement.executeUpdate();
                connection.commit();
                saveStatus = true;
            }
        } catch (DeadLockException deadlockexception1) {
            saveStatus = false;
            Log.error(this, deadlockexception1);

        } finally {
            ioSQL.close(preparedstatement);

            //ioSQL.releaseConnection(connection);
        }

        return saveStatus;
    }

    /**
     * Method to get FX position array given dates and currency.
     * @param start_posdate - start date
     * @param end_posdate - end date
     * @param currency - currency
     * @param connection - connection object
     * @return FXSpotPositionArray - array
     * @throws PersistenceException - exception
     */
    public  FXSpotPositionArray getFXSpotPositions(
        String start_posdate, String end_posdate, String currency,
        Connection connection) throws PersistenceException {
        Statement statement = null;
        FXSpotPositionArray fXSpotPositionArray = new FXSpotPositionArray();

        try {
            JDate temp = Util.stringToJDate(start_posdate);
            start_posdate = Util.date2SQLString(temp);

            // Query to retrieve values from database
            String QUERYSTRING = select_fx_spot_pos;

            if (start_posdate != null) {
                QUERYSTRING = (new StringBuilder()).append(QUERYSTRING)
                               .append(" position_date >= ")
                               .append(start_posdate).toString();
            }

            temp = Util.stringToJDate(end_posdate);
            end_posdate = Util.date2SQLString(temp);

            if (end_posdate != null) {
                QUERYSTRING = (new StringBuilder()).append(QUERYSTRING)
                               .append(" AND position_date <=")
                               .append(end_posdate).toString();
            }

            if (currency != null) {
                QUERYSTRING = (new StringBuilder()).append(QUERYSTRING)
                               .append(" AND currency_code = ").append("'")
                               .append(currency).append("'").toString();
            }

            FXSpotPosition fXSpotPosition = null;
            QUERYSTRING = QUERYSTRING + " order by position_date ";

            statement = ioSQL.newStatement(connection);

            JResultSet jresultset = new JResultSet(
                    statement.executeQuery(QUERYSTRING));

            // Retrieve results from resultset
            while (jresultset.next()) {
                int i = 1; // Dont disturb this
                fXSpotPosition = new FXSpotPosition();
                fXSpotPositionArray.add(fXSpotPosition);
                fXSpotPosition.setDate(jresultset.getJDate(i++));
                fXSpotPosition.setCurrency(jresultset.getString(i++));
                fXSpotPosition.setFXCumulate(jresultset.getDouble(i++));
                fXSpotPosition.setSimulation(jresultset.getDouble(i++));
                fXSpotPosition.setDualCurrency(jresultset.getDouble(i++));
                fXSpotPosition.setFipsBlr(jresultset.getDouble(i++));
            }

            jresultset.close();
        } catch (Exception exception) {
            Log.error(Log.SQL, exception);
            throw new PersistenceException(exception);
        } finally {
            ioSQL.close(statement);
        }

        // Return values to caller
        return fXSpotPositionArray;
    }
}
