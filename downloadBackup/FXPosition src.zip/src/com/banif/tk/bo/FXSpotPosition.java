package com.banif.tk.bo;

/* Java Imports */
import java.io.IOException;
import java.io.ObjectInput;
import java.io.ObjectOutput;
import java.io.Serializable;

/* Calypso Imports */
import com.calypso.tk.core.CalypsoVersion;
import com.calypso.tk.core.JDate;
import com.calypso.tk.util.io.SerializationUtil;
/* End Imports */

/**
 *FX Spot Position class to represent the FX spot
 *position object in the database.
 *@author momohame
 *@version 1.0
 *12/20/2009
 */
public class FXSpotPosition implements Serializable {
     /* Constants. */
    static final long serialVersionUID = 4031720049089403009L;

    /*Date Vriable. */
    protected JDate date;
    /*Position currency. */
    protected String currency;
    /*Position accumulated. */
    protected double fxcumulate;
    /*Position simulation. */
    protected double simulation;
    /*Dual Currency. */
    protected double dualcurrency;
    /*Position fipsblr. */
    protected double fipsblr;
    /*Audit Version. */
    protected int auditversion;
    /*Position Start date. */
    protected JDate startdate;
    /*Position End date. */
    protected JDate enddate;
    /*Position FX rate. */
    protected double fxRate;
    /*Position dc variance. */
    protected double dcvariance;
    /*Position fbvariances. */
    protected double fbvariance;
    /*Position total ex simulation. */
    protected double totalexsim;
    /*Position total. */
    protected double total;
    /*Position fixing. */
    protected double fixing;
    /*Position net value. */
    protected double net;

    /**
     * Default Constructor.
     */
    public FXSpotPosition() {
    }

    /**
     * Getter method to read FX Rate.
     * @return double - fx rate
     */
    public double getFxRate() {
        return fxRate;
    }

    /**
     * Setter method to set FX Rate.
     * @param fxRate - fx rate
     */
    public void setFxRate(double fxRate) {
        this.fxRate = fxRate;
    }

    /**
    * Getter method to read StartDate.
    * @return JDate - start date
    */
    public JDate getStartDate() {
        return startdate;
    }

    /**
     * Setter method to set StartDate.
     * @param sdate - startdate
     */
    public void setStartDate(JDate sdate) {
        startdate = sdate;
    }

    /**
    * Getter method to read END Date.
    * @return JDate - end date
    */
    public JDate getEndDate() {
        return enddate;
    }

    /**
    * Setter method to set END Date.
    * @param edate - end date
    */
    public void setEndDate(JDate edate) {
        enddate = edate;
    }

    /**
    * Getter method to read position Date.
    *@return JDate - position date
    */
    public JDate getDate() {
        return date;
    }

    /**
     * Setter method to set position Date.
     * @param jdate - position date
     */
    public void setDate(JDate jdate) {
        date = jdate;
    }

    /**
    * Getter method to read currency.
    *@return String - currency
    */
    public String getCurrency() {
        return currency;
    }

    /**
    * Setter method to set currency.
    * @param curr - currency
    */
    public void setCurrency(String curr) {
        currency = curr;
    }

    /**
    * Getter method to read dual currency.
    * @return double - dual currency
    */
    public double getDualCurrency() {
        return dualcurrency;
    }

    /**
    * Setter method to read dual currency.
    * @param dualcurr - dual currency
    */
    public void setDualCurrency(double dualcurr) {
        dualcurrency = dualcurr;
    }

    /**
    * Getter method to read FIPSBLR.
    * @return double - fips blr
    */
    public double getFipsBlr() {
        return fipsblr;
    }

    /**
    * Setter method to set FIPS BLR.
    * @param fipblr -  fipsblr
    */
    public void setFipsBlr(double fipblr) {
        fipsblr = fipblr;
    }

    /**
    * Getter method to read FX Cumulate.
    * @return double - fx cumulate
    */
    public double getFXCumulate() {
        return fxcumulate;
    }

    /**
    * Setter method to set cumulate.
    * @param fxcumul - fx cumulate
    */
    public void setFXCumulate(double fxcumul) {
        fxcumulate = fxcumul;
    }

    /**
    * Getter method to read simulation.
    *@return double - simulation
    */
    public double getSimulation() {
        return simulation;
    }

    /**
    * Setter method to Set simulation.
    * @param simulat - simulation
    */
    public void setSimulation(double simulat) {
        simulation = simulat;
    }

    /**
    * Getter method to read DC Variance.
    * @return double - dc variance
    */
    public double getDCVariance() {
        return dcvariance;
    }

    /**
    * Setter method to set DC variance.
    * @param dcv - dc variance
    */
    public void setDCVariance(double dcv) {
        dcvariance = dcv;
    }

    /**
    * Getter method to read FB Variance.
    * @return double - FB Variance
    */
    public double getFBVariance() {
        return fbvariance;
    }

    /**
    * Setter method to set FB Variance.
    * @param fbcv - fb variance
    */
    public void setFBVariance(double fbcv) {
        fbvariance = fbcv;
    }

    /**
    * Getter method to read Total Ex sim.
    * @return double - total ex sm
    */
    public double getTotalExSim() {
        return totalexsim;
    }

    /**
    * Setter method to set Total Ex sim.
    * @param totalsim - total ex simulation
    */
    public void setTotalExSim(double totalsim) {
        totalexsim = totalsim;
    }

    /**
    * Getter method to read total.
    * @return double - total
    */
    public double getTotal() {
        return total;
    }

    /**
    * Setter method to set setTotal.
    * @param tot - total
    */
    public void setTotal(double tot) {
        total = tot;
    }

    /**
    * Getter method to read Fixing.
    * @return double - fixing
    */
    public double getFixing() {
        return fixing;
    }

    /**
    * Setter method to set Fixing.
    * @param fix - fixing
    */
    public void setFixing(double fix) {
        fixing = fix;
    }

    /**
    * Getter method to read Net value.
    * @return double - net
    */
    public double getNet() {
        return net;
    }

    /**
    * Setter method to set Net value.
    * @param netamount - net total
    */
    public void setNet(double netamount) {
        net = netamount;
    }

    /**
     * toString ().
     * @return String - to string
     */
    public String toString() {
        return (new StringBuilder()).append(date).append("/").append(
            currency).append("/").append(dualcurrency).append("/")
                .append(fipsblr).append("/").append(fxcumulate).append("/")
                .append(simulation).toString();
    }

    /**
     * clone().
     * @return Object - clone
     * @throws CloneNotSupportedException - exception
     */
    public Object clone() throws CloneNotSupportedException {
        return super.clone();
    }

    /**
     * writeExternal method.
     * @param objectoutput - object fx spot
     * @throws IOException - exception
     */
    /**
     * @author          : Shobhit Sachdeva
     * @Date(DD/MM/YYYY): 10/11/2014 - updated
     * @Description     : Updated with SerializationUtil.writeTypedObject(JDate, ObjectOutput),
     *                                 SerializationUtil.writeUTF(String, ObjectOutput)
     *                                 as Util.writeDate(JDate, ObjectOutput) and Util.writeUTF(String, ObjectOutput) methods were deprecated.
     */
    public void writeExternal(ObjectOutput objectoutput)
        throws IOException {
    	
        objectoutput.writeInt(CalypsoVersion.getCurrentVersion());
        SerializationUtil.writeTypedObject(date, objectoutput);
        SerializationUtil.writeUTF(currency, objectoutput);
        objectoutput.writeDouble(fxcumulate);
        objectoutput.writeDouble(simulation);
        objectoutput.writeDouble(dualcurrency);
        objectoutput.writeDouble(fipsblr);
    }

    /**
     * readExternal method.
     * @param objectinput - object fx spot
     * @throws IOException - exception
     * @throws ClassNotFoundException - exception
     */
    /**
     * @author          : Shobhit Sachdeva
     * @Date(DD/MM/YYYY): 10/11/2014 - updated
     * @Description     : Updated with SerializationUtil.readTypedObject(Class, ObjectInput),
     *                                 SerializationUtil.readUTF(ObjectOutput)
     *                                 as Util.readDate(ObjectOutput) and Util.readUTF(ObjectOutput) methods were deprecated.
     */
    public void readExternal(ObjectInput objectinput)
        throws IOException, ClassNotFoundException {
        auditversion = objectinput.readInt();
        date = (JDate)SerializationUtil.readTypedObject(com.calypso.tk.core.JDate.class, objectinput);
        currency = SerializationUtil.readUTF(objectinput);
        fxcumulate = objectinput.readDouble();
        simulation = objectinput.readDouble();
        dualcurrency = objectinput.readDouble();
        fipsblr = objectinput.readDouble();
    }

    /**
     * compareTo method.
     * @param obj - object fx spot
     *@return int - compare
     */
    public final int compareTo(Object obj) {
            return 1;
    }
}
