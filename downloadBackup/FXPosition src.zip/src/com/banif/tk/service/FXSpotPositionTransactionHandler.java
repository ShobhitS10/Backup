package com.banif.tk.service;

/* Java imports.*/
import java.rmi.RemoteException;
import java.sql.Connection;
import java.sql.SQLException;

import com.banif.tk.bo.FXSpotPosition;
import com.banif.tk.bo.sql.FXSpotPositionSQL;
import com.calypso.tk.core.Log;
import com.calypso.tk.core.PersistenceException;
import com.calypso.tk.core.sql.ioSQL;
import com.calypso.tk.core.sql.ioSQLBase;
import com.calypso.tk.event.PSConnection;
import com.calypso.tk.service.DSTransactionHandler;
import com.calypso.tk.service.DSTransactionInput;
/* Calypso imports.*/
/* End imports.*/

/**
 *This class will process the database transaction.
 *Process method will be used to either save or retrieve data.
 * @author momohame
 * @version 1.0 - created
 * @date 12/21/2009
 */
public class FXSpotPositionTransactionHandler implements DSTransactionHandler {
    /* FXSpotPositionSQL object. */
    FXSpotPositionSQL fXSpotPositionSQL = new FXSpotPositionSQL();
    boolean flag = false;

    /**
     * From FXSpotPositionTransactionHandler interface.
     * The general sequence for the process method is:
     *
     *    1. Conduct the transaction
     *          a. Get a connection
     *          b. Execute the command
     *          c. Save the event
     *          d. Commit the transaction
     *   2. If any of the above fails, roll back the transaction
     *   3. Finally, release the connection
     *   4. Return results, if applicable
     *
     * Note that this method is originally invoked via a call to the process
     * remote method of the RemoteAccess RMI service.Therefore, the transaction
     * handler will actually be executed within data server memory, *not* within
     * client program memory.
     * @param input - transaction type
     * @param ps - ps connection
     * @return Object - values
     * @exception RemoteException - exception
     */
    /**
     * @author          : Shobhit Sachdeva
     * @Date(DD/MM/YYYY): 10/11/2014 - updated
     * @Description     : Updated deprecated method ioSQL.newConnection() with ioSQLBase.getConnection().
     */
    public Object process(DSTransactionInput input, PSConnection ps)
        throws RemoteException {
        System.out.println("Indside Process method...");

        Object result = null; // Object for any results returned by load.
        Connection con = null; // Released below, outside of the try block

        try {

        	con = ioSQLBase.getConnection();
        	
            FXSpotPositionTransactionInput fxspotInput =
                (FXSpotPositionTransactionInput) input;
            FXSpotPosition fXSpotPosition = fxspotInput
                .getFxSpotPosition();
            String transactionType = fxspotInput.getTransactionType();

            if (fXSpotPosition != null) {
                if (transactionType.equals("save")) {
                    flag = fXSpotPositionSQL.save(fXSpotPosition, con);
                    result = flag;
                    ioSQL.commit(con);
                } else if (transactionType.equals("load")) {
                    result = fXSpotPositionSQL.getFXSpotPositions(
                            fXSpotPosition.getStartDate().toString(),
                            fXSpotPosition.getEndDate().toString(),
                            fXSpotPosition.getCurrency(), con);
                } else {
                    Log.error(this, "Invalid process call..");
                }
            }
        } catch (SQLException e) {
            Log.error(this, e);
            ioSQL.rollback(con);
            throw new RemoteException(e.getMessage());
        } catch (PersistenceException e) {
             Log.error(this, e);
        } finally {
            ioSQL.releaseConnection(con);
        }
        return result;
    }
}
