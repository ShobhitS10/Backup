package com.banif.tk.service;

/* Java imports. */
import java.io.Serializable;

import com.banif.tk.bo.FXSpotPosition;
import com.calypso.tk.service.DSTransactionInput;
/* Calypso imports. */
/* End imports. */

/**
 * Class FXSpotPositionTransactionInput to handle fx spot position handler.
 * @author momohame
 * @version 1.0 - created
 * @date 12/21/2009
 */
public class FXSpotPositionTransactionInput implements DSTransactionInput,
    Serializable {
    /**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	protected FXSpotPosition _fXSpotPosition;
    protected String _transactionType;

    /**
     * Overloaded constructor.
     * @param fXSpotPosition - fx spot position
     * @param transactionType - type
     */
    public FXSpotPositionTransactionInput(
        FXSpotPosition fXSpotPosition, String transactionType) {
        _fXSpotPosition = fXSpotPosition;
        _transactionType = transactionType;
    }

    /**
     * From DSTransactionInput interface.
     * @return String - handler
     */
    public String getHandler() {
        return "com.banif.tk.service.FXSpotPositionTransactionHandler";
    }

    /**
     * Used by the transaction handler.  Returns the object which to apply the
     * persitence transaction to.
     * @return FXSpotPosition - fx spot position
     */
    public FXSpotPosition getFxSpotPosition() {
        return _fXSpotPosition;
    }

    /**
     * Used by the transaction handler.  Tells the transaction handler what type
     * of persistence transaction to perform.
     * @return String - transaction type
     */
    public String getTransactionType() {
        return _transactionType;
    }
}
