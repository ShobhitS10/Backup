package com.banif.tk.util;


/* Java Imports */
import java.io.Externalizable;
import java.io.IOException;
import java.io.ObjectInput;
import java.io.ObjectOutput;
import java.io.Serializable;

import java.util.Arrays;
import java.util.Comparator;
import java.util.Vector;

/* Calypso Imports */
import com.banif.tk.bo.FXSpotPosition;


/**
 *FX Spot Position Array class to represent the FX spot
 *position array object.
 *@author momohame
 *@version 1.0
 *11/30/2009
 */
public final class FXSpotPositionArray implements Serializable, Cloneable,
    Externalizable {
    static final long serialVersionUID = 4664310114738079527L;
    static final int DEFAULT_CAPACITY = 4;
    protected FXSpotPosition[] _bals;
    protected int _size;

    /**
     * Default constructor.
     *
     */
    public FXSpotPositionArray() {
        _bals = new FXSpotPosition[4];
        _size = 0;
    }

    /**
     * Over loaded Constructor.
     * @param vector - position
     */
    /**
     * @author          : Shobhit Sachdeva
     * @Date(DD/MM/YYYY): 10/11/2014 - updated
     * @Description     : Updated parameter of the constructor from Vector to Vector<FXSpotPosition>.
     */
    public FXSpotPositionArray(Vector<FXSpotPosition> vector) {
        _size = vector.size();
        _bals = new FXSpotPosition[Math.max(_size, 4)];

        for (int i = 0; i < _size; i++) {
            _bals[i] = (FXSpotPosition) vector.elementAt(i);
        }
    }

    /**
     * Overloaded Constructor.
     * @param fXSpotPosition - position.
     */
    public FXSpotPositionArray(FXSpotPosition[] fXSpotPosition) {
        setFXSpotPosition(fXSpotPosition);
    }

    /**
     * method grow().
     * @param i - i.
     */
    private void grow(int i) {
        int j = _bals.length;

        if (i > j) {
            FXSpotPosition[] fXSpotPosition = _bals;
            int k = ((j + 1) * 3) / 2;
            k = Math.max(k, i);
            _bals = new FXSpotPosition[k];
            System.arraycopy(fXSpotPosition, 0, _bals, 0, _size);
        }
    }

    /**
     * toVector().
     * @return Vector - vector
     */
    /**
     * @author          : Shobhit Sachdeva
     * @Date(DD/MM/YYYY): 10/11/2014 - updated
     * @Description     : Updated parameter of the constructor from Vector to Vector<FXSpotPosition>.
     *                    Updated generics Vector<FXSpotPosition> in place of Vector to create the vector object.
     */
    public Vector<FXSpotPosition> toVector() {
        Vector<FXSpotPosition> vector = new Vector<FXSpotPosition>(_size);

        for (int i = 0; i < _size; i++) {
            vector.addElement(_bals[i]);
        }

        return vector;
    }

    /**
     * method to set fx spot positions.
     * @param fXSpotPosition - fx spot positions
     */
    public void setFXSpotPosition(FXSpotPosition[] fXSpotPosition) {
        _size = fXSpotPosition.length;

        if (_size > 4) {
            _bals = fXSpotPosition;

            return;
        } else {
            _bals = new FXSpotPosition[Math.max(_size, 4)];
            System.arraycopy(fXSpotPosition, 0, _bals, 0, _size);

            return;
        }
    }

    /**
     * method to get fx spot positions.
     * @return FXSpotPosition - fx spot position
     *
     */
    public FXSpotPosition[] getfXSpotPosition() {
        return _bals;
    }

    /**
     * Method to add fx spot positions.
     * @param fXSpotPosition - fx spot position
     */
    public void add(FXSpotPosition fXSpotPosition) {
        grow(_size + 1);
        _bals[_size++] = fXSpotPosition;
    }

    /**
     * Overloaded method to add fx position in particular position.
     * @param fXSpotPosition - fx spot position
     * @param i - position
     */
    public void add(FXSpotPosition[] fXSpotPosition, int i) {
        grow(_size + i);

        for (int j = 0; j < i; j++) {
            _bals[_size++] = fXSpotPosition[j];
        }
    }

    /**
     * method to add vector of positions.
     * @param vector - positions.
     *
     */
    public  void add(Vector<FXSpotPosition> vector) {
        int i = vector.size();
        grow(_size + i);

        for (int j = 0; j < i; j++) {
            _bals[_size++] = (FXSpotPosition) vector.elementAt(j);
        }
    }

    /**
     * method to find the position at an index.
     * @param fXSpotPosition - fx position.
     * @return int - index
     */
    public int indexOf(FXSpotPosition fXSpotPosition) {
        for (int i = 0; i < _size; i++) {
            if (fXSpotPosition.equals(_bals[i])) {
                return i;
            }
        }

        return -1;
    }

    /**
     * method to remove an FX position.
     * @param fXSpotPosition - fx position
     */
    public void remove(FXSpotPosition fXSpotPosition) {
        int i = indexOf(fXSpotPosition);

        if (i >= 0) {
            remove(i);
        }
    }

    /**
     * method to remove an fx position.
     * @param i - index
     */
    public void remove(int i) {
        int j = _size - i - 1;

        if (j > 0) {
            System.arraycopy(_bals, i + 1, _bals, i, j);
        }

        _bals[--_size] = null;
    }

    /**
     * Method to sort.
     * @param comparator - comparator
     */
    /**
     * @author          : Shobhit Sachdeva
     * @Date(DD/MM/YYYY): 10/11/2014 - updated
     * @Description     : Updated parameter of the constructor from Comparator to Comparator<FXSpotPosition>.
     */
    public void sort(Comparator<FXSpotPosition> comparator) {
        if (_size == 0) {
            return;
        } else {
            Arrays.sort(_bals, 0, _size, comparator);

            return;
        }
    }

    /**
     * Method ot calculate the size.
     * @return int - size
     */
    public  int size() {
        return _size;
    }

    /**
     * Method to find element at.
     * @param i index
     * @return  FXSpotPosition - fx spot position
     */
    public  FXSpotPosition elementAt(int i) {
        return _bals[i];
    }

    /**
     * Method to get position at.
     * @param i - index
     * @return FXSpotPosition - fx spot position
     */
    public  FXSpotPosition get(int i) {
        return _bals[i];
    }

    /**
     * Method to set fx spot position.
     * @param i - index
     * @param fXSpotPosition - fx spot position  value
     */
    public  void set(int i, FXSpotPosition fXSpotPosition) {
        _bals[i] = fXSpotPosition;
    }

    /**
     * Method to check first element.
     * @return FXSpotPosition - fx spot position value at first element.
     */
    public  FXSpotPosition firstElement() {
        return _bals[0];
    }

    /**
     * Method to find last element.
     * @return FXSpotPosition - fx spot position value at last element.
     */
    public  FXSpotPosition lastElement() {
        return _bals[_size - 1];
    }

    /**
     * Method to position array check is empty.
     * @return boolean - flag
     */
    public  boolean isEmpty() {
        return _size == 0;
    }

    /**
     * Method to clear FX spot position array.
     *
     */
    public  void clear() {
        _size = 0;
        _bals = new FXSpotPosition[4];
    }

    /**
     * method to String().
     * @return String - to string
     */
    public String toString() {
        StringBuffer stringbuffer = new StringBuffer();

        if (_size == 0) {
            stringbuffer.append("fXSpotPositionarray Empty");
        } else {
            for (int i = 0; i < _size; i++) {
                stringbuffer.append(
                    (new StringBuilder()).append(_bals[i].toString()).append(
                        " ").toString());
            }
        }

        return stringbuffer.toString();
    }

    /**
     * method makeshallowcopy().
     * @return FXSpotPositionArray - fx spot position array
     */
    public  FXSpotPositionArray makeShallowCopy() {
        FXSpotPositionArray fXSpotPositionarray = new FXSpotPositionArray();
        fXSpotPositionarray._size = _size;
        fXSpotPositionarray._bals = new FXSpotPosition[_size];
        System.arraycopy(_bals, 0, fXSpotPositionarray._bals, 0, _size);

        return fXSpotPositionarray;
    }

    /**
     * Method clone().
     * @return Object - cloned.
     * @exception CloneNotSupportedException - exception
     */
    public Object clone() throws CloneNotSupportedException {
        FXSpotPositionArray fXSpotPositionarray = new FXSpotPositionArray();
        fXSpotPositionarray._size = _size;
        fXSpotPositionarray._bals = new FXSpotPosition[_size];

        for (int i = 0; i < _size; i++) {
            fXSpotPositionarray._bals[i] = (FXSpotPosition) _bals[i].clone();
        }

        return fXSpotPositionarray;
    }

    /**
     * Method to get last fx spot position.
     * @param fXSpotPosition - fx spot position
     * @return FXSpotPosition - fx spot position
     */
    public FXSpotPosition getLastPosition(FXSpotPosition fXSpotPosition) {
        int i = binarySearch(_bals, fXSpotPosition, _size);

        if (i >= 0) {
            return _bals[i];
        }

        int j = -i - 2;

        if (j < 0) {
            return null;
        }

        FXSpotPosition fXSpotPosition1 = _bals[j];

        if (fXSpotPosition1 == null) {
            return null;
        }

        if (fXSpotPosition1.getDate().gte(fXSpotPosition.getDate())) {
            return null;
        }

        fXSpotPosition.setDate(fXSpotPosition1.getDate());

        if (fXSpotPosition.compareTo(fXSpotPosition1) == 0) {
            return fXSpotPosition;
        } else {
            return null;
        }
    }

    /**
     * method for binary search.
     * @param afXSpotPosition - fx spot position array
     * @param fXSpotPosition - fx spot position
     * @param i - index
     * @return int - binary
     */
    public static int binarySearch(
      FXSpotPosition[] afXSpotPosition, FXSpotPosition fXSpotPosition, int i) {
        int j = 0;

        for (int k = i - 1; j <= k;) {
            int l = (j + k) / 2;
            FXSpotPosition fXSpotPosition1 = afXSpotPosition[l];
            int i1 = fXSpotPosition1.compareTo(fXSpotPosition);

            if (i1 < 0) {
                j = l + 1;
            } else if (i1 > 0) {
                k = l - 1;
            } else {
                return l;
            }
        }

        return -(j + 1);
    }

    /**
     * Method writeExternal().
     * @param objectoutput - objectoutput
     * @throws IOException - exception
     */
    public void writeExternal(ObjectOutput objectoutput)
        throws IOException {
        objectoutput.writeInt(_size);

        for (int i = 0; i < _size; i++) {
            _bals[i].writeExternal(objectoutput);
        }
    }

    /**
     * Method readExternal().
     * @param objectinput - objectinput
     * @throws IOException - exception
     * @throws ClassNotFoundException - exception
     */
    public void readExternal(ObjectInput objectinput)
        throws IOException, ClassNotFoundException {
        _size = objectinput.readInt();
        _bals = new FXSpotPosition[Math.max(_size, 4)];

        for (int i = 0; i < _size; i++) {
            _bals[i] = new FXSpotPosition();
            _bals[i].readExternal(objectinput);
        }
    }
}
