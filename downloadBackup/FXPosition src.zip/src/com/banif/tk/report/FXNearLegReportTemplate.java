/**
 * BANIF - Calypso Custom Code
 * 2009, all rights reserved � BANIF
 * $Log: FXNearLegReportTemplate.java,v $
 * Revision 1.3  2009/12/24 10:23:35  svrudhula
 * araman Dec 24, 2009 Project C FX Positions - Updated new Columns in Near Leg as per Client Comments
 *
 * Revision 1.2  2009/11/10 13:01:08  svrudhula
 * araman Nov 10, 2009 Project C FX Positions - Near Leg Report
 * implementation after Unit Testing
 *
 * Revision 1.3  2009/21/12
 * momohame Dec 21, 2009 Project C FX Positions - Near Leg Report
 * Source update for new requirement.
 *
 */
package com.banif.tk.report;

/* List of All Imported Classes */
/* Javax Imports */
import java.util.Vector;

/* Calypso  Imports */
import com.calypso.tk.report.ReportTemplate;

//End of Imports

/**
 *This class is used to design the number of columns in report
 *based on the search criteria given
 *Start Date, End date, and currency.
 * @author momohame
 * @date 10/28/2009
 * @version 1.0
*/
public class FXNearLegReportTemplate extends ReportTemplate {
    static final long serialVersionUID = 4557083713950744547L;

    /* Report search field Currency. */
    public static final String currency = "Currency";

    /* Report search field Start Date. */
    public static final String start_date = "StartDate";

    /* Report search field End Date. */
    public static final String end_date = "EndDate";

    /* Report  Column Date. */
    public static final String date = "Date";

    /* Report  Column  position. */
    public static final String position_accumulated = "Position Acumulated";

    /* Report  Column Simulation. */
    public static final String simulate = "Simulations";

    /* Report  Column Dual Currency. */
    public static final String dual_currency = "Dual Currency";

    /* Report  Column DC_Variance. */
    public static final String dc_variance = "DC_Variance";

    /* Report  Column FIPS Brl. */
    public static final String fips_blr = "FIPS Brl";

    /* Report  Column Total ex-Simulation. */
    public static final String fb_variance = "FB_Variance";

    /* Report  Column Total ex-Simulation. */
    public static final String total_ex_simulation = "Total ex-Simulation";

    /* Report  Column Total. */
    public static final String total = "Total";

    /* Report  Column Fixing. */
    public static final String fixing = "Fixing";

    /* Report  Column Net(Eur). */
    public static final String net = "Net(Eur)";

    /* Report title. */
    private static final String title_key = "Title";
    private static final String title = "FX Near Leg Report";

    /**
    * This method is used to populate the desired columns in report.
    */
    public final void setDefaults() {
        super.setDefaults();
        put(title_key, title);
        Vector<String> vector = new Vector<String>();
        vector.addElement(date);
        vector.addElement(position_accumulated);
        vector.addElement(simulate);
        vector.addElement(dual_currency);
        vector.addElement(dc_variance);
        vector.addElement(fips_blr);
        vector.addElement(fb_variance);
        vector.addElement(total_ex_simulation);
        vector.addElement(total);
        vector.addElement(fixing);
        vector.addElement(net);

        setColumns(
            (String[]) (String[]) vector.toArray(new String[vector.size()]));
    }

    /**
     * This method is used to populate the desired columns in report.
     * @param s - string
     * @return Vector
     */
    public Vector getParameterValues(String s) {
        if (s == null) {
            return null;
        } else {
            return super.getParameterValues(s);
        }
    }
}
