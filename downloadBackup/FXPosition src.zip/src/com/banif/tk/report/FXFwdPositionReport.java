/**
 * BANIF - Calypso Custom Code
 * 2009, all rights reserved � BANIF
 *
 * $Log: FXFwdPositionReport.java,v $
 * Revision 1.2  2009/12/24 10:23:35  svrudhula
 * araman Dec 24, 2009 Project C FX Positions - Updated new Columns in Near Leg as per Client Comments
 *
 *
 */
package com.banif.tk.report;

/* List of All Imported Classes */
/* Java Imports */
import java.rmi.RemoteException;
import java.util.Collections;
import java.util.Hashtable;
import java.util.Vector;
/* Calypso Imports */
import com.calypso.tk.bo.BOPosting;
import com.calypso.tk.core.JDate;
import com.calypso.tk.core.Log;
import com.calypso.tk.core.Trade;
import com.calypso.tk.core.Util;
import com.calypso.tk.core.sql.SQLQuery;
import com.calypso.tk.marketdata.MarketDataException;
import com.calypso.tk.marketdata.PricingEnv;
import com.calypso.tk.marketdata.QuoteValue;
import com.calypso.tk.report.DefaultReportOutput;
import com.calypso.tk.report.Report;
import com.calypso.tk.report.ReportOutput;
import com.calypso.tk.report.ReportRow;
import com.calypso.tk.report.ReportTemplate;
import com.calypso.tk.service.DSConnection;
import com.calypso.tk.util.PostingArray;
import com.calypso.tk.util.TradeArray;
/* Banif Imports */
import com.banif.apps.reporting.FXFwdPosition;
//End of Imports

/**
 * <p>
 * This FXFwdPositionReport class extends the Calypso base
 * com.calypso.tk.report.Report class.
 * The functionality of this class is to calculate cummulative FX Forward
 * Positions and List of Trades that constitute that Position for the
 * specified currency.
 * </p>
 *
 * @author araman
 * @date 2009/10/27
 * @version 1.0
 */
/**
 * @author          : Shobhit Sachdeva
 * @Date(DD/MM/YYYY): 10/11/2014 - updated
 * @Description     : Added default Serial Version Id.
 */
public class FXFwdPositionReport extends Report {

	private static final long serialVersionUID = 1L;
	
	/* Constants */
    private static final String KEY_NPV = "NPV";
    private static final String KEY_NPVCCY = "NPVCCY";
    private static final String FX_FWD_POS = "FXFwdPosition";
    private static final String SUB_TOTAL = "SubTotal";
    private static final String EUR_CCY = "EUR";

   /**
     * <p>
     * This method loads the FX Forward Positions and.
     * List of Trades that constitute that Position on Load Action.
     * </p>
     *
     * @param errorMsgs error messages
     * @return ReportOutput list of ReportRow objects
     */
    @SuppressWarnings("unchecked")
	public ReportOutput load(Vector errorMsgs) {
        DefaultReportOutput output = new DefaultReportOutput(this);
        FXFwdPositionReportTemplate reportTemplate =
                   (FXFwdPositionReportTemplate) getReportTemplate();
        if (reportTemplate == null) {
            PostingArray tempPositioons = new PostingArray();
            ReportRow[] testRows = new ReportRow[tempPositioons.size()];
            output.setRows(testRows);
            return output;
        }
         /* Build Query with search parameters */
        SQLQuery sqlquery = new SQLQuery();
        try {
            buildQuery(sqlquery);
        } catch (Exception exception) {
            Log.error(this, exception);
        }

        String whereQuery = sqlquery.getWhereClause();
        String fromQuery = sqlquery.getFromClause();
        PostingArray postingarray = null;
        fromQuery = Report.removeDuplicateTables(fromQuery);
        if ((fromQuery != null) && (fromQuery.trim().length() == 0)) {
            fromQuery = null;
        }

        /* retrieve list of postings for the specified criteria */
        try {
            postingarray = getDSConnection().getRemoteBO()
                               .getPostings(fromQuery, whereQuery, false);
        } catch (RemoteException exception) {
            Log.error(this, exception);
        }
        if (postingarray == null || postingarray.size() == 0) {
        PostingArray tempPositioons = new PostingArray();
        ReportRow[] testRows = new ReportRow[tempPositioons.size()];
        output.setRows(testRows);
        return output;
        }

        /* Calculates cummulative FX Forward Position */
        Hashtable<JDate, Double> globalPos
                             = new Hashtable<JDate, Double>();
        TradeArray tradesList = new TradeArray();
        Hashtable<JDate, TradeArray> tradesListHash
                            = new Hashtable<JDate, TradeArray>();
        Trade trade = null;
        for (BOPosting posting : postingarray.getPostings()) {
            if (posting != null) {
                JDate tempDate = posting.getEffectiveDate();
                double tempNominal = posting.getOtherAmount();
                tradesList = null;
                if (!globalPos.containsKey(tempDate)) {
                    tradesList = new TradeArray();
                } else {
                    tempNominal = (Double) globalPos.get(tempDate)
                    + tempNominal;
                    tradesList = (TradeArray) tradesListHash.get(tempDate);
                }
                trade = null;
                try {
                    trade = DSConnection.getDefault().getRemoteTrade()
                                        .getTrade(posting.getTradeId());
                    Double npv = posting.getOtherAmount();
                    trade.addKeyword(KEY_NPV, npv.toString());
                    trade.addKeyword(KEY_NPVCCY, posting.getCurrency());
                } catch (RemoteException exception) {
                    Log.error(this, exception);
                }
                tradesList.add(trade);
                tradesListHash.put(tempDate, tradesList);
                globalPos.put(tempDate, tempNominal);
            }
        }

        /* create FXFwdPosition data from BOPosting data */
        Vector<ReportRow> rows = new Vector<ReportRow>();
        FXFwdPosition fwdPosition = null;
        Vector<JDate> keySet = new Vector<JDate>(globalPos.keySet());
        Collections.sort(keySet);
        Hashtable<Integer, Double[]> total = new Hashtable<Integer, Double[]>();
        int lastMonth = 0;
        // Creates FXFwdPosition Value Objects to display in the Report.
        for (JDate obj : keySet) {
            if ((obj != null) && (globalPos.get(obj) != null)) {
                double nominal = new Double(globalPos.get(obj)
                                          .toString()).doubleValue();
                double nominalEur = 0;
                fwdPosition = new FXFwdPosition();
                fwdPosition.setDate(obj);
                fwdPosition.setCurrency((String) reportTemplate
                       .get(FXFwdPositionReportTemplate.CURRENCY));
                fwdPosition.setCummulativeNPV(nominal);
                PricingEnv pricingEnv = getPricingEnv();
                Double fxRate = getQuote(obj, pricingEnv,
                                              fwdPosition.getCurrency());
                if (fxRate != null) {
                    fwdPosition.setFixingRate(fxRate);
                    fwdPosition.setCummulativeNPVEUR(nominal / fxRate);
                    nominalEur = nominal / fxRate;
                } else {
                    fwdPosition.setFixingRate(null);
                    fwdPosition.setCummulativeNPVEUR(null);
                }
                /*
                 * Calculates Sub Total of cummulative positions for each month
                 */
                int month = fwdPosition.getDate().getMonth();
                if (total.containsKey(month)) {
                    Double[] nom = total.get(month);
                    nom[0] = nom[0] + nominal;
                    nom[1] = nom[1] + nominalEur;
                    total.put(month, nom);
                    lastMonth = month;
                } else {
                    if (lastMonth != 0) {
                        rows.add(addition(lastMonth, total.get(lastMonth)));
                    }
                    Double[] nom = {nominal, nominalEur};
                    total.put(month, nom);
                    lastMonth = month;
                }
                /* Sets list of trades that constitute the position */
                tradesList = (TradeArray) tradesListHash.get(obj);
                if ((tradesList != null) && (tradesList.size() != 0)) {
                    fwdPosition.setTrades(tradesList);
                }
                rows.add(new ReportRow(fwdPosition, FX_FWD_POS));
            }
        }
        if (lastMonth != 0) {
            rows.add(addition(lastMonth, total.get(lastMonth)));
        }

        ReportRow[] test = new ReportRow[rows.size()];
        rows.toArray(test);
        output.setRows(test);
        return output;
    }

    /**
     * This method returns the FX Rate for the report currency against EUR.
     *
     * @param date position date
     * @param priceEnv pricing environment
     * @param quotingCCY quoting currency
     * @return FX Rate
     */
    private Double getQuote(JDate date, PricingEnv priceEnv,
                                                  String quotingCCY) {
        QuoteValue quoteValue = null;
        try {
            quoteValue = priceEnv.getFXQuote(EUR_CCY, quotingCCY, date);
        } catch (MarketDataException exception) {
            Log.error(this, exception);
        }
        if (quoteValue != null) {
            return quoteValue.getClose();
        }
        return null;
    }

    /**
     * Creates Row to display Sub Total Month wise.
     * @param month month
     * @param nominal nominal
     * @return ReportRow
     */
    private ReportRow addition(int month, Double[] nominal) {
        FXFwdPosition fwdPosition = new FXFwdPosition();
        fwdPosition.setDate(JDate.valueOf(2009, month, 1));
        fwdPosition.setFixingRate(null);
        fwdPosition.setCurrency(null);
        fwdPosition.setCummulativeNPV(nominal[0]);
        fwdPosition.setCummulativeNPVEUR(nominal[1]);
        return new ReportRow(fwdPosition, SUB_TOTAL);
    }

    /**
     * Builds SQL Query based on search parameters.
     * @param sqlQuery SQl query
     * @return true or exception
     * @throws Exception exception
     */
    protected boolean buildQuery(SQLQuery sqlQuery) throws Exception {
        return buildQuery(sqlQuery, isArchived());
    }

    /**
     * Builds SQL Query based on search parameters.
     * @param sqlquery SQLquery
     * @param flag isArchived
     * @return true or exception
     * @throws Exception exception
     */
    /**
     * @author          : Shobhit Sachdeva
     * @Date(DD/MM/YYYY): 10/11/2014 - updated
     * @Description     : Removed unused variable:
     *                    String currency = farLegTemplate.getColumn(FXFwdPositionReportTemplate.CURRENCY);
     */
    /**
     * @author          : Shobhit Sachdeva
     * @Date(DD/MM/YYYY): 10/11/2014 - updated
     * @Description     : Updated generics "Vector<String>" in place of "Vector" to create the vector object in product type, currency, and posting type criterias.
     */
    protected boolean buildQuery(SQLQuery sqlquery, boolean flag)
        throws Exception {
        ReportTemplate farLegTemplate = _reportTemplate;
        String boPostingTBL = flag ? "bo_posting_hist" : "bo_posting";
        String productTBL = flag ? "product_desc_hist" : "product_desc";
        String strFromDate = (String) farLegTemplate
                        .get(FXFwdPositionReportTemplate.START_DATE);
        String strToDate = (String) farLegTemplate
                              .get(FXFwdPositionReportTemplate.END_DATE);

        /* Adds Start Date and End Date criteria to query */
        JDate fromDate = null;
        if ((strFromDate != null) && (strFromDate.trim().length() > 0)) {
            fromDate = Util.stringToJDate(strFromDate);
        }
        JDate toDate = null;
        if ((strToDate != null) && (strToDate.trim().length() > 0)) {
            toDate = Util.stringToJDate(strToDate);
        }
        StringBuffer stringbuffer = new StringBuffer();
        if (fromDate != null) {
            if (stringbuffer.length() > 0) {
                stringbuffer.append(" AND ");
            }
            stringbuffer.append(boPostingTBL + ".effective_date");
            stringbuffer.append(" >= ");
            stringbuffer.append(Util.date2SQLString(fromDate));
        }
        if (toDate != null) {
            if (stringbuffer.length() > 0) {
                stringbuffer.append(" AND ");
            }
            stringbuffer.append(boPostingTBL + ".effective_date");
            stringbuffer.append(" <= ");
            stringbuffer.append(Util.date2SQLString(toDate));
        }

        /* Adds Product Type criteria to query */
        String parameter = (String) farLegTemplate.get("ProductType");
        if ((parameter != null) && (parameter.trim().length() > 0)) {
            Vector<String> vector = Util.string2Vector(parameter);

            if (stringbuffer.length() > 0) {
                stringbuffer.append(" AND ");
            }
            stringbuffer.append((new StringBuilder()).append(productTBL)
                                 .append(".product_id = ").append(boPostingTBL)
                                 .append(".product_id ").append(" AND ")
                                 .append(productTBL).append(".product_type IN ")
                                 .toString())
                        .append(Util.collectionToSQLString(vector));
        }

        /* Adds Currency criteria to query */
        parameter = (String) farLegTemplate
                    .get(FXFwdPositionReportTemplate.CURRENCY);
        if ((parameter != null) && (parameter.trim().length() > 0)) {
            Vector<String> vector = Util.string2Vector(parameter);
            if (stringbuffer.length() > 0) {
                stringbuffer.append(" AND ");
            }
            stringbuffer.append((new StringBuilder()).append(boPostingTBL)
                                 .append(".currency_code IN ").toString())
                        .append(Util.collectionToSQLString(vector));
        }

        /* Adds Posting Type criteria to query */
        parameter = (String) farLegTemplate
                              .get(FXFwdPositionReportTemplate.POSTING_TYPE);
        if ((parameter != null) && (parameter.trim().length() > 0)) {
            Vector<String> vector = Util.string2Vector(parameter);
            if (stringbuffer.length() > 0) {
                stringbuffer.append(" AND ");
            }
            stringbuffer.append((new StringBuilder()).append(boPostingTBL)
                                 .append(".posting_type IN ").toString())
                        .append(Util.collectionToSQLString(vector));
        }

        /* Adds Event type criteria to query */
        parameter = (String) farLegTemplate
                                .get(FXFwdPositionReportTemplate.ACC_EVENT);
        if ((parameter != null) && (parameter.trim().length() > 0)) {
              if (stringbuffer.length() > 0) {
                stringbuffer.append(" AND ");
            }
            stringbuffer.append((new StringBuilder()).append(boPostingTBL)
                                 .append(".bo_posting_type like '%")
                                 .append(parameter).append("%'"));
        }
        if ((stringbuffer != null) && (stringbuffer.length() == 0)) {
            stringbuffer = null;
        }
        String temp = null;
        if (stringbuffer != null) {
            temp = stringbuffer.toString();
        }
        sqlquery.setWhereClause(temp);
        return true;
    }

    /**
     * Disables Sorting.
     * @return true or false
     */
    public boolean isSortable() {
       return false;
    }

}
