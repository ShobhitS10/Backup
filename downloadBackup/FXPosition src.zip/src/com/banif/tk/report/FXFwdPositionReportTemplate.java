/**
 * BANIF - Calypso Custom Code
 * 2009, all rights reserved � BANIF
 *
 * $Log: FXFwdPositionReportTemplate.java,v $
 * Revision 1.3  2010/01/17 10:16:06  svrudhula
 * araman Jan 17, 2009 Project C FX Positions - Added Report title
 *
 * Revision 1.2  2009/12/24 10:23:35  svrudhula
 * araman Dec 24, 2009 Project C FX Positions - Updated new Columns in Near Leg as per Client Comments
 *
 *
 */
package com.banif.tk.report;

/* List of All Imported Classes */
/* Java Imports */
import java.util.Vector;
/* Calypso Imports */
import com.calypso.tk.report.ReportTemplate;
//End of Imports

/**
 * <p>
 * This FXFwdPositionReportTemplate class extends the calypso base
 * com.calypso.tk.report.ReportTemplate class.
 * And adds new columns for FX Forward Position Report.
 * </p>
 *
 * @author araman
 * @date 2009/10/27
 * @version 1.0
 */
/**
 * @author          : Shobhit Sachdeva
 * @Date(DD/MM/YYYY): 10/11/2014 - updated
 * @Description     : Added default Serial Version Id.
 */
public class FXFwdPositionReportTemplate extends ReportTemplate {

	private static final long serialVersionUID = 1L;
	/** Report search field Currency. */
    public static final String CURRENCY = "Currency";
    /** Report search field Start Date. */
    public static final String START_DATE = "StartDate";
    /** Report search field End Date. */
    public static final String END_DATE = "EndDate";
    /** Report search field Posting Type. */
    public static final String POSTING_TYPE = "PostingType";
    /** Report search field Product Type. */
    public static final String PROD_TYPE = "ProductType";
    /** Report search field Accounting Event Type. */
    public static final String ACC_EVENT = "EventType";
    /** Report column field Date. */
    public static final String POS_DATE = "Date";
    /** Report column field FX Rate. */
    public static final String FX_RATE = "Fixing Rate";
    /** Report column field Currency. */
    public static final String POS_CURRENCY = "Currency";
    /** Report column field Cummulative NPV. */
    public static final String CUMMULATIVE_NPV = "Cumulative NPV";
    /** Report column field Cummulative NVP in EUR. */
    public static final String CUMMULATIVE_NPV_EUR = "Cumulative NPV in EUR";

    /* Constants */
    private static final String POST_DEF_VAL = "NEW";
    private static final String PROD_DEF_VAL = "FXForward,FXSwap,FXNDF";
    private static final String EVE_DEF_VAL = "MTM";
    private static final String TITLE_KEY = "Title";
    private static final String TITLE = "FX Far Leg Position Report";

    /**
     * This method adds new columns for FX Forward Position.
     * And sets the default data.
     */
    public void setDefaults() {
        super.setDefaults();
        //sets default search crietria
        put(POSTING_TYPE, POST_DEF_VAL);
        put(PROD_TYPE, PROD_DEF_VAL);
        put(ACC_EVENT, EVE_DEF_VAL);
        put(TITLE_KEY, TITLE);

        //Add new columns
        Vector<String> vector = new Vector<String>();
        vector.addElement(POS_DATE);
        vector.addElement(FX_RATE);
        vector.addElement(POS_CURRENCY);
        vector.addElement(CUMMULATIVE_NPV);
        vector.addElement(CUMMULATIVE_NPV_EUR);
        setColumns((String[]) (String[]) vector.toArray(
                new String[vector.size()]));
    }

    /**
     * This method is used to populate the desired columns in report.
     * @param s - string
     * @return Vector
     */
    public Vector getParameterValues(String s) {
        if (s == null) {
            return null;
        } else {
            return super.getParameterValues(s);
        }
    }

}
