/**
 * BANIF - Calypso Custom Code
 * 2009, all rights reserved � BANIF
 * $Log: FXPositionDateComparator.java,v $
 * Revision 1.1  2009/11/06 11:25:21  svrudhula
 * araman Nov 6, 2009 Project C FX Positions - Implementation code for Configuring Subtotal Monthwise
 *
 */
package com.banif.tk.report;

/* List of All Imported Classes */
/* Calypso Imports */
import com.calypso.tk.bo.BalancePosition;
import com.calypso.tk.report.DefaultRowComparator;
import com.calypso.tk.report.ReportRow;
/* Banif Imports */
import com.banif.apps.reporting.FXFwdPosition;
//End of Imports

/**
 * This class extends DefaultRowcomparator and used in FXFwdPosition and
 * FXNearLeg reports to gets subtotal monthwise.
 * @author araman
 * @date 10/28/2009
 * @version 1.0
*/
/**
 * @author          : Shobhit Sachdeva
 * @Date(DD/MM/YYYY): 10/11/2014 - updated
 * @Description     : Added default Serial Version Id.
 */
public class FXPositionDateComparator extends DefaultRowComparator {

	private static final long serialVersionUID = 1L;
	private static final String FX_FWD_POS = "FXFwdPosition";
    private static final String BAL_POS = "BALPOS";

    /** Default constructor. */
    public FXPositionDateComparator() {
        super();
    }

    /**
     * Compares two objects. This method compares the position date is same
     * to caluclate subtotal monthwise.
     * @param obj1 First Object
     * @param obj2 Second object
     * @return 0 or 1
     */
    @Override
    public int compare(Object obj1, Object obj2) {
        if ((obj1 == null) || (obj2 == null)) {
            return 0;
        }

        ReportRow reportRow = (ReportRow) obj1;
        ReportRow reportRow1 = (ReportRow) obj2;

        if ((reportRow == null) || (reportRow1 == null)) {
            return 0;
        }

        /* Compares for FX Far Leg reprot */
        Object fxFwdObj1 = reportRow.getProperty(FX_FWD_POS);
        Object fxFwdObj2 = reportRow1.getProperty(FX_FWD_POS);

        if ((fxFwdObj1 != null) && (fxFwdObj2 != null)) {
            FXFwdPosition fxFwd1 = (FXFwdPosition) fxFwdObj1;
            FXFwdPosition fxFwd2 = (FXFwdPosition) fxFwdObj2;

            if ((fxFwd1 == null) || (fxFwd2 == null)) {
                return 0;
            } else {
                if ((fxFwd1.getDate() != null) && (fxFwd2.getDate() != null)
                        && (fxFwd1.getDate().getMonth() == fxFwd2.getDate()
                                              .getMonth())) {
                    return 0;
                } else {
                    return 1;
                }
            }

            /* Compares for FX Near Leg reprot */
        } else {
            fxFwdObj1 = reportRow.getProperty(BAL_POS);
            fxFwdObj2 = reportRow1.getProperty(BAL_POS);

            if ((fxFwdObj1 != null) && (fxFwdObj2 != null)) {
                BalancePosition balPos1 = (BalancePosition) fxFwdObj1;
                BalancePosition balPos2 = (BalancePosition) fxFwdObj2;

                if ((balPos1 == null) || (balPos2 == null)) {
                    return 0;
                } else {
                    if ((balPos1.getPositionDate() != null)
                            && (balPos2.getPositionDate() != null)
                            && (balPos1.getPositionDate().getMonth()
                            == balPos2.getPositionDate().getMonth())) {
                        return 0;
                    } else {
                        return 1;
                    }
                }
            }
        }

        return 0;
    }
}
