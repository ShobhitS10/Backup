/**
 * BANIF - Calypso Custom Code
 * 2009, all rights reserved � BANIF
 *
 * $Log: FXFwdPositionReportStyle.java,v $
 * Revision 1.2  2009/12/24 10:23:35  svrudhula
 * araman Dec 24, 2009 Project C FX Positions - Updated new Columns in Near Leg as per Client Comments
 *
 *
 */
package com.banif.tk.report;

/* List of All Imported Classes */
/* Java Imports */
import java.security.InvalidParameterException;
import java.util.Vector;

import com.banif.apps.reporting.FXFwdPosition;
import com.calypso.tk.core.Amount;
import com.calypso.tk.report.ReportRow;
import com.calypso.tk.report.ReportStyle;
import com.calypso.tk.util.CurrencyUtil;
/* Calypso Imports */
/* Banif Imports */
//End of Imports

/**
 * <p>
 * This FXFwdPositionReportStyle class extends calypso base
 * com.calypso.tk.reoport.ReportStyle class.
 * It returns the values for the report columns.
 * </p>
 *
 * @author araman
 * @date 2009/10/27
 * @version 1.0
 */
/**
 * @author          : Shobhit Sachdeva
 * @Date(DD/MM/YYYY): 10/11/2014 - updated
 * @Description     : Added default Serial Version Id.
 */
public class FXFwdPositionReportStyle extends ReportStyle {

	private static final long serialVersionUID = 1L;
/**
    * Position Date in FX Position Report.
    */
    public static final String POS_DATE = "Date";
    /**
     * FX Rate.
     */
    public static final String FX_RATE = "Fixing Rate";
    /**
     * Report Currency.
     */
    public static final String POS_CURRENCY = "Currency";
    /**
     * Cummulative FX Forward NPV in respective currency.
     */
    public static final String CUMMULATIVE_NPV = "Cummulative NPV";
    /**
     * Cummulative FX Forward NPV in EUR Currency.
     */
    public static final String CUMMULATIVE_NPV_EUR = "Cummulative NPV in EUR";

    /* Constants */
    protected static String[] monthNames = {
            "JAN", "FEB", "MAR", "APR", "MAY", "JUN", "JUL", "AUG", "SEP",
            "OCT", "NOV", "DEC"};
    private static final String FX_FWD_POS = "FXFwdPosition";
    private static final String SUB_TOTAL = "SubTotal";
    private static final String SUB_TOTAL_MSG = " for the month ";

   /**
     * <p>
     * This method overrides the parent method.
     * This method is maps the Column values with RepotOutput Object value
     * </p>
     *
     * @param reportRow Report Row object
     * @param columnId Column Name
     * @param errorMsgs error messages
     * @throws InvalidParameterException exception
     * @return Object value of the Column
     */
    /**
     * @author          : Shobhit Sachdeva
     * @Date(DD/MM/YYYY): 10/11/2014 - updated
     * @Description     : Removed dead code. It was urequired code after creation of FXSpotPosition object.
     *                      if (fxFwd == null) {
     *                          return ret;
     *                      }
     */
    public Object getColumnValue(ReportRow reportRow, String columnId,
        Vector errorMsgs) throws InvalidParameterException {
        Object ret = null;
        boolean subTotal = false;
        if ((reportRow == null) || (columnId == null)
                       || (columnId.trim().length() == 0)) {
            return ret;
        }

        Object fxFwdObj = reportRow.getProperty(SUB_TOTAL);
        if (fxFwdObj != null) {
            subTotal = true;
        } else  {
            fxFwdObj = reportRow.getProperty(FX_FWD_POS);
            subTotal = false;
        }
        if (fxFwdObj != null) {
            FXFwdPosition fxFwd = (FXFwdPosition) fxFwdObj;
            
            //gets number of decimal points for the report currency
            int digits = 0;
            if ((fxFwd.getCurrency() != null)
                          && (fxFwd.getCurrency().trim().length() > 0)) {
                digits = CurrencyUtil.getRoundingUnit(fxFwd.getCurrency());
            }

            if (columnId.equalsIgnoreCase(
                          FXFwdPositionReportTemplate.POS_DATE)) {
                if (!subTotal) {
                    ret = fxFwd.getDate();
                } else {
                    ret = SUB_TOTAL + SUB_TOTAL_MSG
                            + getMonthAsString(fxFwd.getDate().getMonth());
                }
            } else if (columnId.equalsIgnoreCase(
                        FXFwdPositionReportTemplate.FX_RATE)) {
                if (subTotal) {
                    ret = null;
                } else {
                    ret = fxFwd.getFixingRate();
                }
            } else if (columnId.equalsIgnoreCase(
                        FXFwdPositionReportTemplate.CURRENCY)) {
                if (subTotal) {
                    ret = null;
                } else {
                    ret = fxFwd.getCurrency();
                }
            } else if (columnId
                    .equalsIgnoreCase(FXFwdPositionReportTemplate.CUMMULATIVE_NPV)) {
                if (fxFwd.getCummulativeNPV() != null) {
                    ret = new Amount(fxFwd.getCummulativeNPV(), digits);
                } else {
                    ret = null;
                }
            } else if (columnId
                    .equalsIgnoreCase(FXFwdPositionReportTemplate.CUMMULATIVE_NPV_EUR)) {
                if (fxFwd.getCummulativeNPVEUR() != null) {
                    ret = new Amount(fxFwd.getCummulativeNPVEUR(), digits);
                } else {
                    ret = null;
                }
            }
        }
        return ret;
    }

    /**
     * This method returns the name of the month.
     * @param monNum number of month
     * @return name of the month
     */
    public static String getMonthAsString(int monNum) {
        if (monNum < 1) {
            return null;
        }
        if (monNum > monthNames.length) {
            return null;
        } else {
            return monthNames[monNum - 1];
        }
    }
}
