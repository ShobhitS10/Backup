/**
 * BANIF - Calypso Custom Code
 * 2009, all rights reserved � BANIF
 *
 * $Log: FXNearLegReport.java,v $
 * Revision 1.6  2010/02/02 07:58:06  svrudhula
 * Updated,  New formula - MOMOHAME - Feb 2, 2010
 *
 * Revision 1.5  2010/01/19 14:01:14  svrudhula
 * Updated
 *
 * Revision 1.4  2010/01/18 06:11:14  svrudhula
 * Updated
 *
 * Revision 1.3  2009/12/24 10:23:35  svrudhula
 * araman Dec 24, 2009 Project C FX Positions - Updated new Columns in Near Leg as per Client Comments
 *
 * Revision 1.2  2009/11/10 13:01:08  svrudhula
 * araman Nov 10, 2009 Project C FX Positions - Near Leg Report
 * implementation after Unit Testing
 *
 * Revision 1.3  12/21/2009
 * momohame  Dec 21, 2009 Project C FX Positions - Near Leg Report
 * Source modified in order to match new requirement.
 *
 */
package com.banif.tk.report;


/* List of All Imported Classes */

/* Javax Imports */
import java.rmi.RemoteException;

import java.util.Hashtable;
import java.util.Vector;

/* Calypso Imports */
import com.banif.tk.bo.FXSpotPosition;
import com.banif.tk.service.FXSpotPositionTransactionInput;
import com.banif.tk.util.FXSpotPositionArray;

import com.calypso.tk.core.Holiday;
import com.calypso.tk.core.JDate;
import com.calypso.tk.core.Log;
import com.calypso.tk.core.Util;
import com.calypso.tk.marketdata.MarketDataException;
import com.calypso.tk.marketdata.PricingEnv;
import com.calypso.tk.marketdata.QuoteValue;
import com.calypso.tk.refdata.CurrencyDefault;
import com.calypso.tk.report.DefaultReportOutput;
import com.calypso.tk.report.Report;
import com.calypso.tk.report.ReportOutput;
import com.calypso.tk.report.ReportRow;
import com.calypso.tk.service.DSConnection;
import com.calypso.tk.service.RemoteAccess;
import com.calypso.tk.util.CurrencyUtil;


//End of Imports

/**
 * This class reads the data from database with respect to the search criteria
 *given in the report.
 *Based on Start Date, End date, and currecny data retreived.
 *@author momohame
 *@date 10/28/2009
 *@version 1.0
 *
*/
/**
 * @author          : Shobhit Sachdeva
 * @Date(DD/MM/YYYY): 10/11/2014 - updated
 * @Description     : Added default Serial Version Id.
 */
public class FXNearLegReport extends Report {

	private static final long serialVersionUID = 1L;

	/* Base Currency. */
    private static final String EUR_CCY = "EUR";

    /* report currency. */
    String currency =  null;

    /**
     * Default Constructor.
     *
     */
    public FXNearLegReport() {
    }

    /**
     * This is the overrided method and used to load the data from database
     * during the report loading process.
     * @param vector1 - Vector
     * @return Reportoutput
     *
     */
    public final ReportOutput load(final Vector vector1) {
        FXSpotPositionArray loadedFXSpotArray = null;
        FXSpotPosition newFXSpot = null;
        String balpos = "BALPOS";
        newFXSpot = new FXSpotPosition();
        DefaultReportOutput defaultreportoutput = new DefaultReportOutput(this);

        String endDate = (String) _reportTemplate.get(
                FXNearLegReportTemplate.END_DATE);
        String startDate = (String) _reportTemplate.get(
                FXNearLegReportTemplate.START_DATE);
        currency = _reportTemplate.get(FXNearLegReportTemplate.currency)
                                  .toString();
        try {
            newFXSpot.setStartDate(Util.stringToJDate(startDate));
            newFXSpot.setEndDate(Util.stringToJDate(endDate));
            newFXSpot.setCurrency(currency);

            FXSpotPositionTransactionInput loadInstructions =
                new FXSpotPositionTransactionInput(newFXSpot, "load");
            DSConnection ds = DSConnection.getDefault();
            RemoteAccess r = ds.getRemoteAccess();
            loadedFXSpotArray = (FXSpotPositionArray) r.process(loadInstructions);
/*            loadedFXSpotArray = (FXSpotPositionArray) DSConnection.getDefault()
                               .getRemoteAccess().process(loadInstructions);*/
        } catch (RemoteException e) {
            Log.error(this, e);
        } catch (Exception e) {
            Log.error(this, e);
        }

        if ((loadedFXSpotArray != null) && (loadedFXSpotArray.size() > 0)) {
            Vector<ReportRow> rows = new Vector<ReportRow>();
            int i = 0;
            Hashtable<Integer, Double> total = new Hashtable<Integer, Double>();
            int lastMonth = 0;

            for (FXSpotPosition fXSpot : loadedFXSpotArray.getfXSpotPosition()) {
                if (fXSpot != null) {
                    FXSpotPosition spotpos = null;

                    try {
                        spotpos = processRow(fXSpot);
                    } catch (RemoteException e) {
                        Log.error(this, e);
                    }
                    int month = spotpos.getDate().getMonth();
                    if (total.containsKey(month)) {
                        double nom = total.get(month);
                       nom = nom + spotpos.getNet();
                        total.put(month, nom);
                        lastMonth = month;
                    } else {
                        if (lastMonth != 0) {
                            rows.add(addition(lastMonth, total.get(lastMonth)));
                        }
                      total.put(month, spotpos.getNet());
                        lastMonth = month;
                    }
                    rows.add(new ReportRow(spotpos, balpos));
                    i++;
                }
            }
            if (lastMonth != 0) {
                rows.add(addition(lastMonth, total.get(lastMonth)));
            }
            ReportRow[] test = new ReportRow[rows.size()];
            rows.toArray(test);
            defaultreportoutput.setRows(test);
        }

        return defaultreportoutput;
    }

    /**
     * Creates Row to display Sub Total Month wise.
     * @param month month
     * @param nominal nominal
     * @return ReportRow
     */
    private ReportRow addition(int month, double nominal) {
        FXSpotPosition fxPosition = new FXSpotPosition();
        fxPosition.setDate(JDate.valueOf(2009, month, 1));
        fxPosition.setCurrency("");
        fxPosition.setNet(nominal);

        return new ReportRow(fxPosition, "Subtotal");
    }

    /**
     * Method to process fs spot position.
     * @param fxPos - FXSpotPosition
     * @return FXSpotPosition - FXSpotPosition
     * @throws RemoteException - exception
     */
    private FXSpotPosition processRow(FXSpotPosition fxPos)
        throws RemoteException {
    	int i = 1;
    	 CurrencyDefault cd = CurrencyUtil.getCurrencyDefault(currency);
             Vector holidays = cd.getDefaultHolidays();
             Holiday hd = Holiday.getCurrent();
        /* For dual currency previous. */
        FXSpotPositionArray loadedFXSpotArray2 = null;
        FXSpotPosition newFXSpotprvs = null;

        FXSpotPosition spotPosition = new FXSpotPosition();
        newFXSpotprvs = new FXSpotPosition();
        
        
        newFXSpotprvs.setStartDate(hd.previousBusinessDay(fxPos.getDate(), holidays));
        newFXSpotprvs.setEndDate(hd.previousBusinessDay(fxPos.getDate(),holidays));
        newFXSpotprvs.setCurrency(currency);

        FXSpotPositionTransactionInput loadInstructions2 =
             new FXSpotPositionTransactionInput(newFXSpotprvs, "load");
        loadedFXSpotArray2 = (FXSpotPositionArray) DSConnection.getDefault()
                             .getRemoteAccess().process(loadInstructions2);

        for (FXSpotPosition fXSpotprvs : loadedFXSpotArray2.getfXSpotPosition()) {
             
        	if(i==1){
            	
            	
                if (fXSpotprvs != null) {
                  spotPosition.setDCVariance(
                       fxPos.getDualCurrency() - fXSpotprvs.getDualCurrency());
                   spotPosition.setFBVariance(
                       fxPos.getFipsBlr() - fXSpotprvs.getFipsBlr());
               } else {
               	spotPosition.setDCVariance(
               			fxPos.getDualCurrency());
               	spotPosition.setFBVariance(
                           fxPos.getFipsBlr());
               } 
                
                
           	}
                i++;
        }
        try {
            spotPosition.setCurrency(fxPos.getCurrency());
            spotPosition.setDate(fxPos.getDate());
            spotPosition.setDualCurrency(fxPos.getDualCurrency());
            spotPosition.setFipsBlr(fxPos.getFipsBlr());
            spotPosition.setFXCumulate(fxPos.getFXCumulate());
            spotPosition.setSimulation(fxPos.getSimulation());

            double fxRate = getQuote(
                    fxPos.getDate(), getPricingEnv(), fxPos.getCurrency());
            JDate yday = fxPos.getDate().addDays(-1);
            double ydayFxRate = getQuote(
                    yday, getPricingEnv(), fxPos.getCurrency());
            spotPosition.setFxRate(fxRate);

            double cum = 0;
            spotPosition.setTotalExSim(
                fxPos.getFXCumulate() - spotPosition.getDCVariance());
                
            cum = (fxPos.getFXCumulate() + fxPos.getSimulation())
                - spotPosition.getDCVariance();
            spotPosition.setTotal(cum);
            spotPosition.setFixing(fxRate);

            if ((fxRate != 0) && (ydayFxRate != 0)) {
            	
            	spotPosition.setNet((cum / fxRate) - (cum / ydayFxRate));
            } else {
                 spotPosition.setNet(0);
            }
        } catch (Exception e) {
           Log.error(this, e);
        }

        return spotPosition;
    }

    /**
     * Method tells whether report values are sortable.
     * @return boolean - sortable
     */
    public boolean isSortable() {
        return false;
    }

    /**
     * This method returns the FX Rate for the report currency against EUR.
     *
     * @param date position date
     * @param priceEnv pricing environment
     * @param quotingCCY quoting currency
     * @return FX Rate
     */
    private double getQuote(JDate date, PricingEnv priceEnv, String quotingCCY) {
    	CurrencyDefault cd = CurrencyUtil.getCurrencyDefault(EUR_CCY);
    	Vector holidays = cd.getDefaultHolidays();
    	Holiday hd = Holiday.getCurrent();
        QuoteValue quoteValue = null;

        if (!hd.isBusinessDay(date, holidays)) {
            date = hd.previousBusinessDay(date, holidays);
        }

        try {
            quoteValue = priceEnv.getFXQuote(EUR_CCY, quotingCCY, date);
        } catch (MarketDataException exception) {
            Log.error(this, exception);
        }

        if (quoteValue != null) {
            return quoteValue.getClose();
        }

        return 0;
    }
}
