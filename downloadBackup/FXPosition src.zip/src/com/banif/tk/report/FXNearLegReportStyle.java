/**
 * BANIF - Calypso Custom Code
 * 2009, all rights reserved � BANIF
 * $Log: FXNearLegReportStyle.java,v $
 * Revision 1.5  2010/02/02 07:58:20  svrudhula
 * Updated,  New formula - MOMOHAME - Feb 2, 2010
 *
 * Revision 1.4  2009/12/24 10:23:35  svrudhula
 * araman Dec 24, 2009 Project C FX Positions - Updated new Columns in Near Leg as per Client Comments
 *
 * Revision 1.2  2009/11/10 13:01:08  svrudhula
 * araman Nov 10, 2009 Project C FX Positions - Near Leg Report
 * implementation after Unit Testing
 *
 *
 *Revision 1.3  2009/12/12
 * momohame dec 12, 2009 Project C FX Positions - Near Leg Report
 * Modified the columns as per new requirement.
 */
package com.banif.tk.report;


/* List of All Imported Classes */
/* Javax Imports */
import java.util.Vector;

/* Calypso Imports */
import com.banif.tk.bo.FXSpotPosition;
import com.calypso.tk.core.Amount;
import com.calypso.tk.report.ReportRow;
import com.calypso.tk.report.ReportStyle;
import com.calypso.tk.util.CurrencyUtil;


//End of Imports

/**
 *This class populates the value for all columns in report
 *based on the search criteria given.
 *Based on Start Date, End date, and currecny data retreived.
 * @author momohame
 * @date 10/28/2009 - created
 * @version 1.0
 */
/**
 * @author          : Shobhit Sachdeva
 * @Date(DD/MM/YYYY): 10/11/2014 - updated
 * @Description     : Added default Serial Version Id.
 */
public class FXNearLegReportStyle extends ReportStyle {

	private static final long serialVersionUID = 1L;

	/**
    * Default constructor.
    */
    public FXNearLegReportStyle() {
    }

    /**
     * This method is used to populate and return values into report.
     * during the report loading process
     * @param reportrow - ReportRow
     * @param s - column name
     * @param vector - vector
     * @return Object - column values
     *
     */
    /**
     * @author          : Shobhit Sachdeva
     * @Date(DD/MM/YYYY): 10/11/2014 - updated
     * @Description     : Removed dead code. It was urequired code after creation of FXSpotPosition object.
     *                      if (spotPosition == null) {
     *                          return null;
     *                      }
     */
    public Object getColumnValue(ReportRow reportrow, String s, Vector vector) {
        if ((reportrow == null) || (s == null) || (s.length() == 0)) {
            return null;
        }
        Object colValue = null;
        boolean subTotal = false;
        Object fxFwdObj = reportrow.getProperty("Subtotal");

        if (fxFwdObj != null) {
            subTotal = true;
        } else {
            fxFwdObj = reportrow.getProperty("BALPOS");

            if (fxFwdObj != null) {
                subTotal = false;
            } else {
                return null;
            }
        }
        FXSpotPosition spotPosition = (FXSpotPosition) fxFwdObj;
        
        //gets number of decimal points for the report currency
        int digits = 2;
        if (
            (spotPosition.getCurrency() != null)
                && (spotPosition.getCurrency().trim().length() > 0)) {
            digits = CurrencyUtil.getRoundingUnit(spotPosition.getCurrency());
        }
        if (subTotal) {
            if (s.equalsIgnoreCase(FXNearLegReportTemplate.date)) {
                return "Subtotal for the month of "
                + FXFwdPositionReportStyle.getMonthAsString(
                    spotPosition.getDate().getMonth());
            } else if (s.equalsIgnoreCase(FXNearLegReportTemplate.net)) {
                return new Amount(spotPosition.getNet(), digits);
            } else {
                return null;
            }
        }
        if (s.equalsIgnoreCase(FXNearLegReportTemplate.date)) {
            colValue = spotPosition.getDate();
        } else if (
            s.equalsIgnoreCase(FXNearLegReportTemplate.position_accumulated)) {
            colValue = new Amount(spotPosition.getFXCumulate(), digits);
        } else if (s.equalsIgnoreCase(FXNearLegReportTemplate.simulate)) {
            colValue = new Amount(spotPosition.getSimulation(), digits);
        } else if (s.equalsIgnoreCase(FXNearLegReportTemplate.dual_currency)) {
            colValue = new Amount(spotPosition.getDualCurrency(), digits);
        } else if (s.equalsIgnoreCase(FXNearLegReportTemplate.dc_variance)) {
            colValue = new Amount(spotPosition.getDCVariance(), digits);
        } else if (s.equalsIgnoreCase(FXNearLegReportTemplate.fips_blr)) {
            colValue = new Amount(spotPosition.getFipsBlr(), digits);
        } else if (s.equalsIgnoreCase(FXNearLegReportTemplate.fb_variance)) {
            colValue = new Amount(spotPosition.getFBVariance(), digits);
        } else if (
            s.equalsIgnoreCase(FXNearLegReportTemplate.total_ex_simulation)) {
            colValue = new Amount(spotPosition.getTotalExSim(), digits);
        } else if (s.equalsIgnoreCase(FXNearLegReportTemplate.total)) {
            colValue = new Amount(spotPosition.getTotal(), digits);
        } else if (s.equalsIgnoreCase(FXNearLegReportTemplate.fixing)) {
            colValue = spotPosition.getFixing();
        } else if (s.equalsIgnoreCase(FXNearLegReportTemplate.net)) {
            colValue = new Amount(spotPosition.getNet(), digits);
        }

        return colValue;
    }
}
