/**
 * BANIF - Calypso Custom Code
 * 2009, all rights reserved � BANIF
 *
 * $Log: FXNearLegReportWindowHandler.java,v $
 * Revision 1.1  2010/01/15 05:38:55  svrudhula
 * araman Jan 15, 2009 Project C FX Positions - Added New Report Handler
 *
 * Revision 1.2  2009/12/28 11:39:26  svrudhula
 * araman Dec 28, 2009 Project C FX Positions - Sort Menu disabled
 *
 *
 *
 */
package com.banif.apps.reporting;

/* List of All Imported Classes */
/* Java Imports */
import java.awt.Component;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JPopupMenu;

import com.calypso.apps.reporting.ReportWindow;
import com.calypso.apps.reporting.ReportWindowHandlerAdapter;

// End of Imports

/**
 * <p>
 * This class extends the calypso base class ReportWindowHandlerAdapter. It
 * enables/disables menu Items in the Menu bar and uttons in Bottom panel of the
 * report.
 * </p>
 * 
 * @author araman
 * @date 2009/12/24
 * @version 1.0
 */
public class FXNearLegReportWindowHandler extends ReportWindowHandlerAdapter {

    /** Default constructor. */
    public FXNearLegReportWindowHandler() {
    }

    /**
     * This method Customizes Report Window. Disables sort menu and removes load
     * all buttons.
     * 
     * @param reportWindow
     *            ReportWindow
     */
    public void customizeReportWindow(ReportWindow reportWindow) {
        /* customizes Menu bar - disables sort menu and removes load all */
        if (reportWindow.getJMenuBar() != null) {
            JMenuBar mainMenu = reportWindow.getJMenuBar();
            if (mainMenu != null && mainMenu.getComponentCount() > 1) {
                JMenu loadMenu = mainMenu.getMenu(0);
                
                loadMenu = mainMenu.getMenu(1);
                if (loadMenu != null) {
                    JPopupMenu popUpMenu = loadMenu.getPopupMenu();
                    if (popUpMenu != null) {
                        Component comp = null;
                        comp = popUpMenu.getComponent(4);
                        if (comp != null) {
                            comp.setEnabled(false);
                        }
                            comp = popUpMenu.getComponent(5);
                            if (comp != null) {
                                comp.setEnabled(false);
                            }
                            comp = popUpMenu.getComponent(7);
                            if (comp != null) {
                                comp.setEnabled(false);
                            }
                            comp = popUpMenu.getComponent(8);
                            if (comp != null) {
                                comp.setEnabled(false);
                            }
                            comp = popUpMenu.getComponent(9);
                            if (comp != null) {
                                comp.setEnabled(false);
                            }
                        }
                    }
                }
            }
        }

       
       
    }

   

