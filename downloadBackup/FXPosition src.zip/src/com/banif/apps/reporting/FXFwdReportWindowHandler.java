/**
 * BANIF - Calypso Custom Code
 * 2009, all rights reserved � BANIF
 *
 * $Log: FXFwdReportWindowHandler.java,v $
 * Revision 1.2  2009/12/28 11:39:26  svrudhula
 * araman Dec 28, 2009 Project C FX Positions - Updated code for Report Clear
 *
 * Revision 1.1  2009/12/24 10:23:34  svrudhula
 * araman Dec 24, 2009 Project C FX Positions - Updated new Columns in Near Leg as per Client Comments
 *
 *
 */
package com.banif.apps.reporting;

/* List of All Imported Classes */
/* Java Imports */
import java.awt.Component;
import java.awt.Container;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JPanel;
import javax.swing.JPopupMenu;
import javax.swing.JTabbedPane;
import javax.swing.JTextField;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;
/* Calypso Imports */
import com.calypso.apps.reporting.ReportWindow;
import com.calypso.apps.reporting.ReportWindowHandlerAdapter;
import com.calypso.apps.util.CalypsoCollapsiblePanel;

// End of Imports

/**
 * <p>
 * This class extends the calypso base class ReportWindowHandlerAdapter. It
 * enables/disables menu Items in the Menu bar and uttons in Bottom panel of the
 * report.
 * </p>
 * 
 * @author araman
 * @date 2009/12/24
 * @version 1.0
 */
public class FXFwdReportWindowHandler extends ReportWindowHandlerAdapter {

    /** Default constructor. */
    public FXFwdReportWindowHandler() {
    }

    /**
     * This method Customizes Report Window. Disables sort menu and removes load
     * all buttons.
     * 
     * @param reportWindow
     *            ReportWindow
     */
    public void customizeReportWindow(ReportWindow reportWindow) {
        /* customizes Menu bar - disables sort menu and removes load all */
        if (reportWindow.getJMenuBar() != null) {
            JMenuBar mainMenu = reportWindow.getJMenuBar();
            if (mainMenu != null && mainMenu.getComponentCount() > 1) {
                JMenu loadMenu = mainMenu.getMenu(0);
                if (loadMenu != null) {
                    JPopupMenu popUpMenu = loadMenu.getPopupMenu();
                    if (popUpMenu != null) {
                        if (popUpMenu.getComponentCount() > 3) {
                            popUpMenu.remove(2);
                        }
                    }
                }
                loadMenu = mainMenu.getMenu(1);
                if (loadMenu != null) {
                    JPopupMenu popUpMenu = loadMenu.getPopupMenu();
                    if (popUpMenu != null) {
                        Component comp = null;
                        if (popUpMenu.getComponentCount() > 9) {
                            comp = popUpMenu.getComponent(2);
                            if (comp != null) {
                                comp.setEnabled(true);
                            }
                            comp = popUpMenu.getComponent(4);
                            if (comp != null) {
                                comp.setEnabled(false);
                            }
                            comp = popUpMenu.getComponent(5);
                            if (comp != null) {
                                comp.setEnabled(false);
                            }
                            comp = popUpMenu.getComponent(7);
                            if (comp != null) {
                                comp.setEnabled(false);
                            }
                            comp = popUpMenu.getComponent(8);
                            if (comp != null) {
                                comp.setEnabled(false);
                            }
                            comp = popUpMenu.getComponent(9);
                            if (comp != null) {
                                comp.setEnabled(false);
                            }
                        }
                    }
                }
            }
        }

        // Removing buttons in the Additional Parameters of the report
        if (reportWindow.getContentPane() != null) {
            Container mainWindow = reportWindow.getContentPane();
            // traversing to the bottom panel and removing Load all buttons in
            // the
            // main window component
            if (mainWindow != null && mainWindow.getComponentCount() > 2) {
                Component comp = mainWindow.getComponent(2);
                if (comp != null && comp instanceof JPanel) {
                    JPanel subPanel1 = (JPanel) comp;
                    if (subPanel1 != null && subPanel1.getComponentCount() > 0) {
                        comp = subPanel1.getComponent(0);
                        if (comp != null && comp instanceof JPanel) {
                            subPanel1 = (JPanel) comp;
                            if (subPanel1 != null
                                    && subPanel1.getComponentCount() > 2) {
                                comp = subPanel1.getComponent(2);
                                if (comp != null && comp instanceof JPanel) {
                                    subPanel1 = (JPanel) comp;
                                    if (subPanel1 != null
                                            && subPanel1.getComponentCount() > 0) {
                                        comp = subPanel1.getComponent(0);
                                        if (comp != null
                                                && comp instanceof JPanel) {
                                            subPanel1 = (JPanel) comp;
                                            if (subPanel1 != null
                                                    && subPanel1
                                                            .getComponentCount() > 13) {
                                                comp = subPanel1
                                                        .getComponent(13);
                                                if (comp instanceof JButton) {
                                                    JButton loadButton = (JButton) comp;
                                                    loadButton.setText("Load");
                                                    loadButton.setBounds(212,
                                                            42, 75, 24);
                                                }
                                                comp = subPanel1
                                                        .getComponent(5);
                                                if (comp instanceof JLabel) {
                                                    comp.setVisible(false);
                                                }
                                                comp = subPanel1
                                                        .getComponent(6);
                                                if (comp instanceof JTextField) {
                                                    comp.setVisible(false);
                                                }
                                                comp = subPanel1
                                                        .getComponent(7);
                                                if (comp instanceof JTextField) {
                                                    comp.setVisible(false);
                                                }
                                                subPanel1.remove(12);
                                                if (reportWindow.getTabPanel() != null) {
                                                    JTabbedPane tabPane = reportWindow
                                                            .getTabPanel();
                                                    if (tabPane != null) {
                                                        tabPane
                                                                .addChangeListener(new JTabbedPanelChangeAdapter(
                                                                        reportWindow));
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    /**
     * This Class implement Change Listener
     */
    class JTabbedPanelChangeAdapter implements ChangeListener {
        ReportWindow adaptee;

        /**
         * Constructor. Sets the Report Window Object
         * 
         * @param adaptee
         *            report window
         */
        JTabbedPanelChangeAdapter(ReportWindow adaptee) {
            this.adaptee = adaptee;
        }

        /**
         * This method changes behavior when selected different tabs.
         */
        /**
         * @author          : Shobhit Sachdeva
         * @Date(DD/MM/YYYY): 10/11/2014 - updated
         * @Description     : Removed dead code. It was urequired code after creation of JTabbedPane object.
         *                      if (tabPane == null) {
         *                          return;
         *                      }
         */
        public void stateChanged(ChangeEvent event) {
            Object source = event.getSource();
            if (source != null && source instanceof JTabbedPane) {
                JTabbedPane tabPane = (JTabbedPane) source;
                
                int tabSelected = tabPane.getSelectedIndex();
                // when position tab selected
                if (tabSelected == 1) {
                    tabChange(false);
                    // when Trades tab selected
                } else if (tabSelected == 0) {
                    tabChange(true);
                }
            }
        }

        /**
         * Make Visible or Invisible depend on the tab selected.
         * @param enable true or false
         */
        private void tabChange(boolean enable) {
            if (this.adaptee != null) {
                Component comp = null;
                // set visible or not for buttons in bottom panel of the report.
                if (this.adaptee.getContentPane() != null) {
                    Container mainWindow = this.adaptee.getContentPane();
                    if (mainWindow != null
                            && mainWindow.getComponentCount() > 2) {
                        JPanel subPanel = null;
                        comp = mainWindow.getComponent(0);
                        if (comp != null && comp instanceof JPanel) {
                            subPanel = (JPanel) comp;
                            if (subPanel != null
                                    && subPanel.getComponentCount() > 0) {
                                comp = subPanel.getComponent(0);
                                if (comp != null
                                        && comp instanceof CalypsoCollapsiblePanel) {
                                    CalypsoCollapsiblePanel cPanel = (CalypsoCollapsiblePanel) comp;
                                    cPanel.setVisible(enable);
                                }
                            }
                        }
                        comp = mainWindow.getComponent(2);
                        if (comp != null && comp instanceof JPanel) {
                            subPanel = (JPanel) comp;
                            if (subPanel != null
                                    && subPanel.getComponentCount() > 0) {
                                comp = subPanel.getComponent(0);
                                if (comp != null && comp instanceof JPanel) {
                                    subPanel = (JPanel) comp;
                                    if (subPanel != null
                                            && subPanel.getComponentCount() > 2) {
                                        comp = subPanel.getComponent(2);
                                        if (comp != null
                                                && comp instanceof JPanel) {
                                            subPanel = (JPanel) comp;
                                            if (subPanel != null
                                                    && subPanel
                                                            .getComponentCount() > 0) {
                                                comp = subPanel.getComponent(0);
                                                if (comp != null
                                                        && comp instanceof JPanel) {
                                                    subPanel = (JPanel) comp;
                                                    if (subPanel != null) {
                                                        int count = subPanel
                                                                .getComponentCount();
                                                        if (count > 12) {
                                                            comp = subPanel
                                                                    .getComponent(12);
                                                            if (comp != null) {
                                                                comp
                                                                        .setVisible(enable);
                                                            }
                                                            comp = subPanel
                                                                    .getComponent(0);
                                                            if (comp != null) {
                                                                comp
                                                                        .setVisible(enable);
                                                            }
                                                            comp = subPanel
                                                                    .getComponent(1);
                                                            if (comp != null) {
                                                                comp
                                                                        .setVisible(enable);
                                                            }
                                                        }
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }

                // set visible or not for menu items in the report.
                if (this.adaptee.getJMenuBar() != null) {
                    JMenuBar mainMenu = this.adaptee.getJMenuBar();
                    if (mainMenu != null && mainMenu.getComponentCount() > 0) {
                        JMenu subMenu = mainMenu.getMenu(0);
                        if (subMenu != null) {
                            JPopupMenu popUpMenu = subMenu.getPopupMenu();
                            if (popUpMenu != null
                                    && popUpMenu.getComponentCount() > 2) {
                                comp = popUpMenu.getComponent(1);
                                if (comp != null) {
                                    comp.setVisible(enable);
                                }
                            }
                        }
                    }
                }
            }
        }
    }
    /* ............. End Of Inner Class .............................. */

}
