/**
 * BANIF - Calypso Custom Code
 * 2009, all rights reserved � BANIF
 * $Log: FXFwdPosition.java,v $
 * Revision 1.2  2009/12/24 10:23:34  svrudhula
 * araman Dec 24, 2009 Project C FX Positions - Updated new Columns in Near Leg as per Client Comments
 *
 */
package com.banif.apps.reporting;

/* List of All Imported Classes */
/* Calypso Imports */
import com.calypso.tk.core.JDate;
import com.calypso.tk.util.TradeArray;
//End of Imports

/**
 * This class used as the Value Object for holding position date,
 * position currency, cumuulaviive NPV and cummulative NVP in EUR
 * values for any particular's Position to show FX Forward positions.
 *
 * @author araman
 * @date 2007/10/27
 * @version 1.0
 */
public class FXFwdPosition {
    /** Position Date. */
    private JDate date = null;

    /** FX rate for the report currency against EUR. */
    private Double fixingRate = 0.;

    /** Currency having the position. */
    private String currency = null;

    /** Collection of all the trades NPV ,for the report currency. */
    private Double cummulativeNPV = 0.;

    /** Cummulative NPV in EUR currency. */
    private Double cummulativeNPVEUR = 0.;

    /** List of trades constituting the position. */
    private TradeArray trades = null;

    /**
     * @return cummulative NPV.
     */
    public Double getCummulativeNPV() {
        return cummulativeNPV;
    }

    /**
     * @param npv sets cummulative NVP.
     */
    public void setCummulativeNPV(Double npv) {
        this.cummulativeNPV = npv;
    }

    /**
     * @return cummulative NPV in EUR.
     */
    public Double getCummulativeNPVEUR() {
        return cummulativeNPVEUR;
    }

    /**
     * @param npvEur sets cummulative NPV in EUR.
     */
    public void setCummulativeNPVEUR(Double npvEur) {
        this.cummulativeNPVEUR = npvEur;
    }

    /**
     * @return currency
     */
    public String getCurrency() {
        return currency;
    }

    /**
     * @param ccy Set the currency.
     */
    public void setCurrency(String ccy) {
        this.currency = ccy;
    }

    /**
     * @return position date.
     */
    public JDate getDate() {
        return date;
    }

    /**
     * @param posDate set the position date.
     */
    public void setDate(JDate posDate) {
        this.date = posDate;
    }

    /**
     * @return fx rate
     */
    public Double getFixingRate() {
        return fixingRate;
    }

    /**
     * @param fxRate set the market fx rate.
     */
    public void setFixingRate(Double fxRate) {
        this.fixingRate = fxRate;
    }

    /**
     * @return list of trades.
     */
    public TradeArray getTrades() {
        return trades;
    }

    /**
     * @param tradeArray sets the list of trades.
     */
    public void setTrades(TradeArray tradeArray) {
        this.trades = tradeArray;
    }
}
