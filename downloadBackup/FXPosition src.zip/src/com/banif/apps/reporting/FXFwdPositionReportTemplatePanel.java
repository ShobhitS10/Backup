/**
 * BANIF - Calypso Custom Code
 * 2009, all rights reserved � BANIF
 * $Log: FXFwdPositionReportTemplatePanel.java,v $
 * Revision 1.5  2010/01/19 14:07:28  svrudhula
 * araman Jan 18, 2009 Project C FX Positions -SIT Fixes - Clearing Trades Tab
 *
 * Revision 1.4  2010/01/17 10:16:06  svrudhula
 * araman Jan 17, 2009 Project C FX Positions - Added Report title
 *
 * Revision 1.3  2009/12/28 11:39:26  svrudhula
 * araman Dec 28, 2009 Project C FX Positions - Updated code for Report Clear
 *
 * Revision 1.2  2009/12/24 10:23:34  svrudhula
 * araman Dec 24, 2009 Project C FX Positions - Updated new Columns in Near Leg as per Client Comments
 *
 */
package com.banif.apps.reporting;

/* List of All Imported Classes */
/* Java Imports */
import java.awt.Component;
import java.awt.Dimension;
import java.awt.Font;
/* Javax Imports */
import javax.swing.JLabel;
import javax.swing.JTextField;
import javax.swing.SwingConstants;
import javax.swing.JTabbedPane;
/* Calypso Imports */
import com.calypso.apps.reporting.ReportPanel;
import com.calypso.apps.reporting.ReportTemplatePanel;
import com.calypso.apps.util.AppUtil;
import com.calypso.apps.util.CalypsoComboBox;
import com.calypso.tk.core.JDate;
import com.calypso.tk.core.Log;
import com.calypso.tk.core.Util;
import com.calypso.tk.refdata.UserDefaults;
import com.calypso.tk.report.ReportTemplate;
import com.calypso.tk.service.DSConnection;
/* Banif imports */
import com.banif.tk.report.FXFwdPositionReportTemplate;
//End of Imports

/**
 * <p>
 * This class extends the calypso abstract class
 * com.calypso.apps.reporting.ReportTemplatePanel.
 * It creates the Search Criteria panel for FX Forward Positions.
 * </p>
 *
 * @author araman
 * @date 2009/10/27
 * @version 1.0
 */
/**
 * @author          : Shobhit Sachdeva
 * @Date(DD/MM/YYYY): 10/11/2014 - updated
 * @Description     : Added default Serial Version Id.
 */
public  class FXFwdPositionReportTemplatePanel  extends ReportTemplatePanel {

	private static final long serialVersionUID = 1L;
	/* DECLARE_CONTROLS */
    JLabel searchCriteriaLabel;
    JLabel fromDateLabel;
    JTextField fromDateText;
    JLabel toDateLabel;
    JTextField toDateText;
    JLabel currencyLabel;
    CalypsoComboBox currencyText;
    //END OF CONTROLS

    protected ReportTemplate template;

    /* Constants */
    private static final String EMPTY_STRING = "";
    private static final String DEF_CCY = "EUR";
    private static final String ERROR_MSG_MANDATORY = "Start Date and End Date"
                                               + " are mandatory";
    private static final String ERROR_MSG_DATEVAL = "End Date should be after"
                                             + " Start Date";
    /* Label Text */
    private static final String LABEL_SEARCH_CRITERIA = "Search Criteria";
    private static final String LABEL_FROM_DATE = "Start Date";
    private static final String LABEL_CCY = "Currency";
    private static final String LABEL_TO_DATE = "End Date";

    /**
     * Default Constructor.
     */
    public FXFwdPositionReportTemplatePanel() {
        //initializes the Controls
        searchCriteriaLabel = new JLabel();
        fromDateLabel = new JLabel();
        toDateLabel = new JLabel();
        fromDateText = new JTextField();
        toDateText = new JTextField();
        currencyLabel = new JLabel();
        currencyText = new CalypsoComboBox();

        try {
            jbInit();
        } catch (Exception e) {
            Log.error(this, e);
        }
        initDomains();
    }

    /**
     * sets the Format and alignment for the controls and layout of the window.
     * @throws Exception throws exception
     */
    private void jbInit() throws Exception {
        setLayout(null);
        setSize(new Dimension(300, 200));
        Font boldFont = new Font("Dialog", 1, (int) 12);

        //Defining Search Components
        searchCriteriaLabel.setVerticalTextPosition(SwingConstants.TOP);
        searchCriteriaLabel.setHorizontalAlignment(SwingConstants.LEFT);
        searchCriteriaLabel.setText(LABEL_SEARCH_CRITERIA);
        searchCriteriaLabel.setFont(boldFont);
        searchCriteriaLabel.setBounds(16, 8, 170, 24);

        fromDateLabel.setVerticalTextPosition(SwingConstants.TOP);
        fromDateLabel.setHorizontalAlignment(SwingConstants.RIGHT);
        fromDateLabel.setText(LABEL_FROM_DATE);
        fromDateLabel.setBounds(16, 59, 170, 24);
        fromDateText.setText(EMPTY_STRING);
        fromDateText.setBounds(190, 59, 154, 24);

        toDateLabel.setVerticalTextPosition(SwingConstants.TOP);
        toDateLabel.setHorizontalAlignment(SwingConstants.RIGHT);
        toDateLabel.setText(LABEL_TO_DATE);
        toDateLabel.setBounds(440, 59, 170, 24);
        toDateText.setText(EMPTY_STRING);
        toDateText.setBounds(614, 59, 154, 24);

        currencyLabel.setVerticalTextPosition(SwingConstants.TOP);
        currencyLabel.setHorizontalAlignment(SwingConstants.RIGHT);
        currencyLabel.setText(LABEL_CCY);
        currencyLabel.setBounds(16, 100, 170, 24);
        currencyText.setBounds(190, 100, 154, 24);
        currencyText.setEditable(false);

        //Adding search Components
        add(searchCriteriaLabel);
        add(fromDateLabel);
        add(fromDateText);
        add(toDateLabel);
        add(toDateText);
        add(currencyLabel);
        add(currencyText);
    }

    /**
     * Initilizes the data for the controls.
     */
    protected void initDomains() {
        AppUtil.addDateListener(fromDateText);
        AppUtil.addDateListener(toDateText, fromDateText);
        AppUtil.set(currencyText, AppUtil.getCurrencies(), true, null);
        setDefaults();
    }

    /**
     * Sets default data for the controls.
     */
    private void setDefaults() {
        fromDateText.setText(EMPTY_STRING);
        toDateText.setText(EMPTY_STRING);
        currencyText.setSelectedItem(DEF_CCY);
     }

    /**
     * @return Retrieves the ReportTemplate.
     */
    public ReportTemplate getTemplate() {
        this.template.put(FXFwdPositionReportTemplate.START_DATE,
                                   this.fromDateText.getText());
        this.template.put(FXFwdPositionReportTemplate.END_DATE,
                                     this.toDateText.getText());
        this.template.put(FXFwdPositionReportTemplate.CURRENCY,
                              this.currencyText.getSelectedItem());
        return this.template;
    }

    /**
     * set the ReportTemplate.
     * @param template report template
     * 
     */
    public void setTemplate(ReportTemplate template) {
        if (template != null) {

            this.template = template;
            UserDefaults  userDefaults = DSConnection.getDefault()
                                                         .getUserDefaults();

            String fieldValue = null;
            fieldValue = (String) template.get(
                             FXFwdPositionReportTemplate.START_DATE);
            if (fieldValue == null || fieldValue.trim().length() == 0) {
                fromDateText.setText(EMPTY_STRING);
            } else {
                fromDateText.setText(fieldValue);
            }
            fieldValue = (String) template.get(
                            FXFwdPositionReportTemplate.END_DATE);
            if (fieldValue == null || fieldValue.trim().length() == 0) {
                toDateText.setText(EMPTY_STRING);
            } else {
                toDateText.setText(fieldValue);
            }
            fieldValue = (String) template.get(
                            FXFwdPositionReportTemplate.CURRENCY);
            if (fieldValue == null || fieldValue.trim().length() == 0) {
                if (userDefaults !=  null
                         && userDefaults.getPricingEnvName() != null) {
                    currencyText.setSelectedItem(
                                  userDefaults.getPricingEnvName());
                }
            } else {
                currencyText.setSelectedItem(fieldValue);
            }
        }
   }

    /**
     * This method is called before Load.
     * @param panel Report Panel
     */
    public void callBeforeLoad(ReportPanel panel) {
        ReportTemplate temp = panel.getTemplate();
        if (temp == null) {
            return;
        }
    }

    /**
     * This method is called after load method and sets the window.
     * @param panel Report panel
     */
    public void callAfterDisplay(ReportPanel panel) {
        ReportTemplate temp = panel.getTemplate();
        if (temp != null) {
            setTemplate(temp);
        }
    }

    /**
     * This method is called before Load action and contain the validations.
     * @param panel Report Panel
     * @return true or false based on verifictaion
     */
    public boolean isValidLoad(ReportPanel panel) {
        String fromDate = this.fromDateText.getText();
        String toDate = this.toDateText.getText();
        clearTradeTab();
        /* Checks for Mandatory fields */
        if (fromDate == null || fromDate.trim().length() == 0
                || toDate == null || toDate.trim().length() == 0) {
            panel.clear();
            AppUtil.displayError(ERROR_MSG_MANDATORY, this);
            return false;
        }
        /* Checks Report Start Date is before Report End date */
        JDate startDate = Util.stringToJDate(fromDate);
        JDate endDate = Util.stringToJDate(toDate);
        if (startDate != null && endDate != null) {
            if ((!startDate.equals(endDate) && !endDate.after(startDate))) {
                panel.clear();
                AppUtil.displayError(ERROR_MSG_DATEVAL, this);
                return false;
            }
        }
        return super.isValidLoad(panel);
    }

    /** Clears Trades tab Panel. */
    public void clearTradeTab() {
        JTabbedPane reportTabs = getReportWindow().getTabPanel();
        if (reportTabs != null && reportTabs.getComponentCount() > 1) {
            Component tab = reportTabs.getComponent(1);
            if (tab != null && tab instanceof ReportPanel) {
                ((ReportPanel)tab).clear();
            }
        }
    }
}
