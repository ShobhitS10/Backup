package gui;

public interface PrefsListener {
	public void preferencesSet(String user, String password, int port);
}
